# export02 只读输入

本目录保存配套操作包中 export02 原始会话、既有审计和结果表的副本，供 B-X02 起离线使用。原件仍在操作包内，未修改。

| 文件 | 用途 |
| --- | --- |
| `spectrum_session_a79f9a7236b2_export02.zip` | 9 个 run、3542 帧、28 份完整频谱留样的原始会话 |
| `export02_audit.json` | 既有独立审计结果 |
| `frequency_results.csv` | 既有频率结果表 |
| `metric_results.csv` | 既有指标结果表 |

会话 SHA256：`3E7FFF49310213C024F073566E5420B5F69727BD9E9C225698B90D7272EBD62E`。

使用时先解压到 `reports/` 或临时工作目录，绝不能写回该只读目录或原始 run 目录。长测的 3100 条逐帧指标不等于 3100 份完整频谱留样。
