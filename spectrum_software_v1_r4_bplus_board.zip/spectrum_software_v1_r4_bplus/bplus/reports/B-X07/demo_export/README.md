# b_plus_v1 B-X07 分析导出包

- 来源：BOARD_LIVE 原始归档，当前为 REPLAY。
- `analysis_summary.json` 记录参数、样本范围、曲线、游标、趋势和事件。
- `.npy` 为单边线性幅度数组，非复数 FFT。
- 这是扩展自己的结果，旧会话审计器不宣称已完整验收本格式。
- 重算命令：`python recompute_export.py --package <本目录> --extension-root <b_plus_v1>`。
