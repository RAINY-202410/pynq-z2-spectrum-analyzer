# B-X07 集成分析工作台与可重算导出

日期：2026-10-31（Asia/Shanghai）。扩展版本：`b_plus_v1_B-X07_v1`。板端 `board_accepted=false`。

## 工作台

启动 `python plus_app.py` 后打开 `http://127.0.0.1:8765/`。页面首屏保留：

- 原始来源 `BOARD_LIVE` 与当前 REPLAY 模式；
- run、原始 elapsed_s、窗类型、采样率、硬件 sequence；
- 当前谱/均方幅度平均谱/峰值保持曲线；
- A/B 实际 FFT bin 游标与差值；
- 目标频段/最大局部峰趋势、缺测和阈值事件；
- 分析包导出按钮。

`?demo=bx07&range=5000` 会加载双音留样、放置 A/B 游标并生成目标频段趋势。`?demo=bx07&range=5000&export=1` 还会通过页面自身 POST 导出分析包。

## 导出包

真实演示包：`reports/B-X07/demo_export/`。

包内包含：

| 文件 | 内容 |
| --- | --- |
| `analysis_summary.json` | 来源、BOARD_LIVE/REPLAY 区分、run、窗口、fs/N、样本范围、曲线、游标、趋势/事件摘要 |
| `parameters.json` | 观察帧、当前帧、平均长度、游标曲线/bin、趋势阈值和规则 |
| `source_index.json` | 原始会话哈希、观察留样成员路径和逐文件哈希 |
| `mean_square_average.npy` | 单边线性均方幅度平均数组 |
| `peak_hold.npy` | 单边线性峰值保持数组 |
| `current_amplitude.npy` / `selected_curve_amplitude.npy` | 当前谱与所选测量曲线的线性数组 |
| `frequency_hz.npy` | 实际频率轴 |
| `cursor_readings.json` | A/B 读数、Δf、ΔL、线性幅比 |
| `trend.json` / `events.json` | 逐帧趋势和真实 REPLAY 阈值事件 |
| `manifest.json` | 包内文件 SHA256 |
| `recompute_export.py` | 独立重算入口 |

## 重算

```powershell
python recompute_export.py `
  --package reports\B-X07\demo_export `
  --extension-root .
```

重算会重新读取归档 words/state、调用冻结解析器、重算平均/保持和游标，并重新运行趋势规则。当前真实演示包已验证：

- 观察 frame 1、40；当前 frame 40；
- 平均 2 份、保持 2 份；
- 双音 A/B bin 21/64；
- 40 个趋势指标点、0 个事件；
- `ok=true`，无失败项。

## 页面证据和演示

- `integrated_workbench.png`：集成页面和趋势面板。
- `integrated_workbench_dom.html`：执行 JavaScript 后的 DOM。
- `integrated_export.png`：页面实际触发导出后的上下文与结果。
- `integrated_export_dom.html`：导出后 DOM。
- `demo.mp4`：由实际渲染截图和真实数据趋势图组成的短演示片；不是实板屏幕录像。
- `manifest.json`：本目录证据文件的 SHA256。

## 边界

- 选中的四个 run 只保留 20 份完整频谱；长测 3100 条指标不等于完整谱。
- 页面和导出保持 `source_mode=LIVE`、`display_mode=REPLAY`；不把回放当作新采集。
- 峰值保持和趋势事件只代表已保存观测，不能证明未采样瞬态或物理断线。
- 扩展包有自己的 manifest；旧会话审计器不声称已完整验收这个扩展格式。
- 幅值未做物理电压标定；没有加载 Overlay 或访问 DMA。

## 验证

- 页面 `?demo=bx07&range=5000` 实际渲染 A/B bin 21/64、当前/平均/保持曲线、趋势面板和导出按钮。
- 页面实际 POST `/api/export` 返回 200，并生成 14 文件包；导出结果在 `integrated_export.png` 可见。
- `recompute_export.py --package reports/B-X07/demo_export --extension-root .` 返回 `ok=true`。
- 全套测试 44/44 通过；B-X01 基线 147 项检查、0 失败。
- `demo.mp4` 为 12 秒离线演示片（实际页面截图和真实数据趋势图），不是实板屏幕录像。
