# B-X10 同步双声道相量拟合

日期：2026-10-31（Asia/Shanghai）。本目录使用 B-X09 的 SYNTHETIC 数据验证算法；没有 M4 板端实测。

## 输入格式与通道

- M4 原始块：`(2,1024)`，left/right 两路同步时域样本。
- 原始整数格式：signed24 存在 int32 中，归一化除以 `2**23`。
- 左声道：`input_reference`；右声道：`rc_output`。
- 当前 FFT v1.0 的左声道 FFT 不参与此拟合；不能把两次独立单声道抓取相减。

## 拟合

对同一块数据使用同一个频率 `f`：

```text
x[n] ≈ ax*cos(2πfn/fs) + bx*sin(2πfn/fs) + cx
y[n] ≈ ay*cos(2πfn/fs) + by*sin(2πfn/fs) + cy
Cx = ax - j*bx
Cy = ay - j*by
H_raw = Cy/Cx
```

使用 `numpy.linalg.lstsq(..., rcond=None)`；在标称频率附近做一维共同频率残差搜索。
输出残差、参考/输出幅度、矩阵 rank/condition、数据范围、增益、相位和有效状态。
参考过弱、削顶候选、拟合差、秩不足或条件数过高都会标记无效及原因。

## B-X09 SYNTHETIC 结果

| 案例 | 真值增益/相位 | 拟合增益/相位 | 状态 |
| --- | --- | --- | --- |
| 平坦、1 kHz + 0.2 Hz | 0 dB / 0° | ≈0 dB / 0° | VALID |
| 截止附近、+0.3 Hz | -6.0206 dB / -45° | ≈-6.0206 dB / -45° | VALID |
| 8 kHz、+0.4 Hz | -20 dB / -80° | ≈-20 dB / -80° | VALID |
| 弱参考 | 0 dB / 0° | — | REFERENCE_WEAK |

B-X10 额外验证了 0.5 增益的 0°/-45°/-90°、不同初始相位、公共频偏和直流偏置；有效案例的系数误差测试门槛为 `1e-6`。削顶候选和弱参考不进入有效结果。

## 文件

- `fit_results.json`：B-X09 结果和 B-X10 synthetic validation 全部细节。
- `fit_results.csv`：B-X09 真值/拟合/残差/有效性摘要。
- `manifest.json`：本目录文件 SHA256。

## 边界

- 本目录没有 M4 板端数据；`board_accepted=false`。
- 弱参考/削顶/拟合差只标记候选和无效原因，不声称具体物理故障。
- 实际 M4 采集、直通校准和 RC 实测属于 B-X11/B-X12。
- 只有同一同步块内的左右声道才能计算复数传递比。
