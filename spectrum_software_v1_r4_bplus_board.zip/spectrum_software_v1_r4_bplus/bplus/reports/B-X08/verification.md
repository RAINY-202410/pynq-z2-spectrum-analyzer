# B-X08 离线验证记录

状态：`OFFLINE_VERIFIED_BOARD_LIVE_PENDING`。日期：2026-10-31。

## 步骤状态

| 步骤 | 状态 | 依据 |
| --- | --- | --- |
| B-X01 | HOST_VALIDATED | 147 项基线检查，0 失败 |
| B-X02 | REPLAY_VALIDATED | 4 run、3220 指标、20 谱；真实归档重放 |
| B-X03 | REPLAY_VALIDATED | 原始 frame 顺序、暂停/不循环、稀疏缺口 |
| B-X04 | REPLAY_VALIDATED | 线性和均方平均、保持、8/32、reset |
| B-X05 | REPLAY_VALIDATED | A/B 实际 bin、Δf/ΔL、零幅度比值不适用 |
| B-X06 | REPLAY_VALIDATED | 保存峰趋势、缺测、迟滞、长间隔断点 |
| B-X07 | REPLAY_VALIDATED | 集成页面、页面导出、独立重算 |
| B-X08 离线 | OFFLINE_VERIFIED | 合成 `/api/status` fixture、去重/缺口/只读 |
| B-X08 BOARD_LIVE | NOT_EXECUTED | 需 r2 数据保全和服务安排后短测 |

## 关键检查

- 全套测试 `48/48` 通过；B-X01 基线 `147` 项检查、0 失败。
- 坏哈希、缺成员、错误窗口/帧元数据均拒绝。
- 真实留样时间顺序和原始 frame_id 索引保持；暂停不累计。
- 平均/保持公式、重复 frame 去重、跨组 reset 和 32 份内存上限通过。
- 双音 A/B 实际 bin 21/64，零幅度不产生线性幅比。
- 趋势只使用最多三个保存峰；静音目标频段 40/40 缺测；合成事件覆盖迟滞/恢复/缺测/长间隔。
- B-X07 真实演示包 `recompute_export.py` 返回 `ok=true`。
- 离线订阅接受 4 帧、重复 1 次、跳过 1 次、记录 1 个 frame 缺口。
- `live_subscription.py` 只有状态 GET 路径；未执行任何板端命令。

## 尚未完成

- 未轮询实际 `192.168.2.99:8091/api/status`，因此不能登记 BOARD_LIVE 订阅通过。
- 未实现跨域只读代理；后续只在 B 的本地服务中做只读转发，不开放基线控制接口。
- 实时采样的短测需要等 r2 原始结果保全完成；不要求重跑 30 分钟。
