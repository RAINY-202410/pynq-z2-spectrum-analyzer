# B-X08 离线只读订阅

日期：2026-10-31（Asia/Shanghai）。本目录只完成 B-X08 的离线部分；实际 BOARD_LIVE 订阅仍未执行。

## 实现

`live_subscription.py` 只读取既有状态的 `GET /api/status`：

- 不初始化 `LiveSource`；
- 不调用 `/api/start`、`/api/stop`、`/api/render` 或其他控制接口；
- 不加载 PYNQ、Overlay 或 DMA；
- 将最新帧只读转发到已有的 `SpectrumAccumulator`，并保留逐帧 metrics 供趋势计算。

去重键为：

```text
(service_address, process_id, run_id, frame_id)
```

当前 r3 状态顶层没有 `latest.frame_id` 字段，因此离线适配器在缺省时使用 `status.frames` 作为 frame_id 回退；如果未来状态帧显式提供 `latest.frame_id`，则优先使用该字段。没有假设存在新的 `instance_id`。

## 离线运行

```powershell
python live_subscription.py `
  --fixture reports\B-X08\status_fixture.jsonl `
  --out reports\B-X08
```

输出 `subscription_report.json`。没有使用 `--url`，所以本轮没有访问任何板端服务。

未来实时只读试用可用：

```powershell
python live_subscription.py `
  --url http://192.168.2.99:8091/api/status `
  --count 5
```

该命令仍只 GET 状态；必须在 r2 数据保全和服务安排完成后再执行，不重跑 30 分钟长测。

## 离线 fixture 结果

`status_fixture.jsonl` 是合成状态序列，不是板端故障记录：

- 接受 4 帧；
- 相同 service/process/run/frame 重复轮询 1 次，被忽略；
- `latest=None` 状态 1 次，被跳过；
- frame 2→5，记录缺少 2 帧的观测缺口；
- run A→run B 和 process 切换后，特征/history 重置；
- 最终 run B 的特征平均/保持各 1 份。

`subscription_report.json` 记录 transcript、缺口、最终特征摘要和 read-only/endpoint scope。
`manifest.json` 记录本目录 fixture、报告和验证文件的 SHA256。

## 边界

- 本轮是 `OFFLINE_FIXTURE` 验证，不是 BOARD_LIVE 验证。
- 状态接口可能重复返回同一最新帧；只计一次，不把轮询次数当帧数。
- 发现 frame/sequence 跳号时只记录缺口，不宣称收齐全部采集帧。
- 现有页面继续使用归档 REPLAY；实时接入需要后续短测和服务安排。
