# reports

`b_plus_v1` 的所有扩展分析输出放在本目录。不得写入 `baseline_readonly/`、`inputs_readonly/` 或原始 export02 run 目录。

建议每次分析使用独立子目录，例如：

```text
reports/<analysis_run_id>/
  analysis_summary.json
  sample_index.json
  events.json
  manifest.json
```

`export_results.resolve_report_path()` 会拒绝绝对路径、`..`、盘符和逃逸到本目录之外的路径。
