# B-X11 完整 16 频点直通校准数据

日期：2026-11-01（Asia/Shanghai）。状态：`BOARD_VALIDATED`。

## 数据

原始数据位于 `../audio_test/`：

- 16 个频点；
- 每点 3 个校准块；
- 每点 3 个有效验证块；
- 6 kHz 的 `b11_f6000_val_03.npy` 因幅度突然跌落被保留为失败记录；
- 6 kHz 使用 `val_01`、`val_02`、`val_retry_01` 作为独立验证集。

采集参考 `fs=47998.77998801426 Hz`，M4 原始格式为 `(2,1024)` int32，左声道 `input_reference`、右声道 `rc_output`。

## 结果

16/16 个频点通过 B-X10 拟合和 B-X11 独立验证。`C0` 增益约 `0.1127～0.1140 dB`，相位约 `-0.0186°～+0.0130°`；各点校正后的验证均值接近 `0 dB / 0°`。

6 kHz 补采块：

- 峰值约 `0.114`；
- 拟合频率约 `5999.79 Hz`；
- 增益约 `0.1129 dB`；
- 相位约 `-0.0132°`；
- B-X10 `valid=True`。

## 已记录条件

- PC 音量：`100%`
- 线路：PC 3.5mm 立体声输出直接到 PYNQ-Z2 LINE IN 3.5mm
- 信号：WAV 左右声道复制同一单音；两个输出没有短接
- 温度：`25 C`
- codec：`configure_codec()` 通过，PLL 回读 `0271023c2103`
- `fs`：`47998.77998801426 Hz`
- m4.bit：`07a075244eb332556556c6d46d1a7b8523cbdff8fe6a23527fa33addbe832ef8`
- m4.hwh：`c9721187b8e6aeec91aebb1fda57148ba4c18e395758aef0ec392062ac177f2d`

注意：线路是直连立体声线，不是物理单路分线器；左右 WAV 内容相同且没有短接。
`board_accepted` 仍保持 `false`，这是 B-X11 校准结论，不等于整个作品最终验收。

## 文件

- `channel_calibration.json`：16 点完整校准和验证。
- `fit_results.json`：97 个原始块的 B-X10 拟合结果，包含保留的失败块。
- `calibration_summary.csv`：频点级 C0、验证均值和重复性。
- `calibration_repeatability.png` / `.svg`：C0 和校正后验证结果。
- `manifest.json`：本目录文件哈希。

## 验证

- 全套测试 66/66 通过。
- `channel_calibration.json` 为 16/16 点通过。
- `b11_f6000_val_03.npy` 保留为失败记录，最终 6 kHz 使用 `val_retry_01`。

## 重算

```powershell
python -m rc.build_full_bx11 `
  --dataset-dir reports\B-X11\audio_test `
  --out reports\B-X11\full_20261101
```
