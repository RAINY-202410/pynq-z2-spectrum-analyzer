# B-X11 双通道直通校准

日期：2026-10-31（Asia/Shanghai）。总体状态：`BOARD_VALIDATED`。

完整 16 频点板端数据已于 2026-11-01 收到并通过处理：

- 16/16 点通过独立验证；
- 6 kHz 原 `val_03` 因信号跌落无效，保留为失败记录；
- 6 kHz 使用 `val_01`、`val_02`、`val_retry_01` 三个有效验证块；
- 新的数据在 `full_20261101/`，状态为 `BOARD_VALIDATED`。

已记录条件：PC 音量 100%、PC 3.5mm 立体声直连 PYNQ LINE IN、WAV 左右复制同一
单音、25°C、PLL `0271023c2103`、`fs=47998.77998801426 Hz`。线路是直接立体声线，
不是物理单路分线器；两个源声道内容相同且未短接。

## 信号发生器补充会话

2026-11-01 又收到一组使用信号发生器作为信源的 16 频点直通数据，独立结果在
`signal_generator_20261101/`：

- OWON XDG3122，正弦波，实际 `0.2 Vpp`，`26 C`，标称 `50 Ω` 输出；
- 3.5 mm 立体公转 L/R/GND，发生器输出同时接 L、R，信号地接 GND；
- 96 个正式块全部入选，16/16 点通过；
- `C0` 增益 `0.043404～0.044280 dB`，相位 `-0.019371～+0.012997°`；
- 6 kHz 的 `val_01..03` 均有效；
- 按用户要求完全排除 `b11_f6000_val_retry_01.npy`；
- 状态为 `BOARD_VALIDATED`，信源和线路条件已记录；
- 该组数据与上面 PC 直通数据的 C0 条件不同，不能无说明混用。

## 历史 1 kHz pilot（保留）

使用的是 `b_20261018_1025/M4_for_B/validation/` 中已有的真实 M4 双声道 1 kHz 验证块：

- `cap_01..05`：校准集；
- `cap_06..10`：独立验证集；
- 每块 `(2,1024)` int32，左声道为参考、右声道为输出；
- `fs=47998.2293823345 Hz`。

这些文件是现有验证试点，不是 B-X11 新做的完整 16 频点直通会话；音量、线路和温度条件未记录。

## 历史 1 kHz pilot 结果

`channel_calibration.json` 记录：

- 5 个校准块、5 个独立验证块；
- `C0` 均值约 `0.064254 dB / -0.007763°`；
- 校准增益重复性标准差约 `0.000058 dB`，相位约 `0.000261°`；
- 校正后验证平均约 `-0.000213 dB / 0.000365°`；
- 独立验证在 `0.5 dB / 2°` 的试点阈值内通过。

这只是早期单频 pilot；完整 16 点结果见 `full_20261101/`，不要在最终报告中混用两组
不同条件下的 C0。

## 完整 16 点结果

`full_20261101/` 已包含 16 个频点的完整校准和验证：

- 16/16 点通过；
- C0 增益约 `0.1127～0.1140 dB`；
- C0 相位约 `-0.0186°～+0.0130°`；
- 6 kHz 的低电平 `val_03` 保留为失败记录，使用 `val_retry_01`；
- 每点均使用 3 个校准块和 3 个独立有效验证块。

## 历史 pilot 设计点状态

根目录旧 `channel_calibration.json` 的 `design_points` 是历史 pilot 状态：

- 1000 Hz：`PILOT_M4_1KHZ`；
- 其余 15 个：`NOT_MEASURED`。

没有对空缺点做插值，也没有把 1 kHz 试点复制到其它频率。

## 文件

- `channel_calibration.json`：校准/验证、C0、重复性、条件、设计点状态。
- `raw_pilot/cap_01..10.npy`：复制的 M4 原始块。
- `audio_sources/b11_*Hz.wav`：16 个 B-X11 播放源，48 kHz/16-bit/12 秒，左右声道相同。
- `audio_sources/audio_source_manifest.csv`：频点、幅度、时长和声道对应。
- `calibration_repeatability.png` / `.svg`：原始和校正后的增益/相位重复性。
- `manifest.json`：所有文件 SHA256。

## B-X12 后续

- B-X11 的 16 点板端数据和条件已记录，不需要重跑；
- 若 B-X12 使用信号发生器，应使用 `signal_generator_20261101/` 的 C0；
- B-X12 改接 RC 时，左声道继续作参考，右声道串入 R，C 从右声道节点接 GND，
  不能再让 L/R 直接并联；
- `board_accepted` 仍为 `false`，因为 B-X11 校准通过不等于整个作品发布验收；
- B-X12 再接 RC，并保留回路原始双声道、校准和每点质量状态。

## 验证

- `tests/test_channel_calibration.py` 覆盖历史 1 kHz pilot、完整 16 点、6 kHz 补采、原始块和 manifest。
- 全套测试 66/66 通过。
- 完整数据由用户板端会话采集；本报告处理过程没有加载 M4/Overlay/DMA。

MATLAB 生成脚本在 `matlab/generate_bx11_wavs.m`。当前工作区 MATLAB 启动器报
`File system inconsistency`，因此本目录的 WAV 由等价的 Python fallback
生成并核验；正常 MATLAB 环境可直接运行 `.m` 脚本生成同样的参数。
