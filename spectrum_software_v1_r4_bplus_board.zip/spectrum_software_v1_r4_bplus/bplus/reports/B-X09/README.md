# B-X09 RC 理论基准与 SYNTHETIC 数据

日期：2026-10-31（Asia/Shanghai）。本目录是理论/合成基准，不是实测 RC 结果。

## 实验设计

- 一阶 RC 低通：R=1 kΩ，C=100 nF。
- 传递函数：`H(f)=1/(1+j*2*pi*f*R*C)`。
- 理论截止：`fc=1/(2*pi*R*C)=1591.5494309189535 Hz`。
- 在 fc 处理论幅值约 `-3.010299956639812 dB`，相位 `-45°`。
- 设计频率：200、300、500、700、1000、1200、1400、1500、1592、1700、1900、2200、3000、4000、6000、8000 Hz。截止附近加密；这不代表已实测带宽。

## 文件

| 文件 | 含义 |
| --- | --- |
| `theory.png` / `.svg` | 理论幅频/相频、设计点和独立 SYNTHETIC 真值点 |
| `rc_points.json` | 16 个设计点、空白实测字段、独立 `synthetic_points` |
| `rc_points.csv` | 设计点/理论列；实测 gain/phase 留空 |
| `synthetic_points.csv` | 4 个 SYNTHETIC 案例，独立于实测列 |
| `synthetic/*.npz` | 双声道 1024 点 int32/float 数据、公共频偏和真值 |
| `manifest.json` | 文件哈希 |

## SYNTHETIC 案例

- 平坦增益 0 dB、相位 0°、1 kHz + 0.2 Hz 偏移、不同直流偏置。
- 截止附近 1591.55 Hz + 0.3 Hz、增益 -6.0206 dB、相位 -45°、不同直流偏置。
- 8 kHz + 0.4 Hz、增益 -20 dB、相位 -80°。
- 弱参考案例，标记 `REFERENCE_TOO_WEAK_SYNTHETIC`，用于后续拟合拒绝路径。

所有案例都标记 `source=SYNTHETIC`；真值放在 `truth_*` 字段，不填入实测 gain/phase 列。

## 验证

- `tests/test_rc_model.py` 验证 fc、-3.0103 dB/-45°、16 个空白设计点、合成 NPZ 格式/真值、CSV 分表和 manifest 哈希。
- 全套测试 53/53 通过。
- 没有板端 Overlay/PYNQ/DMA 动作；`board_accepted=false`。
- 实际 R/C、直通校准和 RC 测量留给 B-X11/B-X12。
