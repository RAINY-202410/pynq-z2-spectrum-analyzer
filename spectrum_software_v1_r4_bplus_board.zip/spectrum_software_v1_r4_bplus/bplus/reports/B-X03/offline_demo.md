# B-X03 离线回放演示

演示日期：2026-10-31（Asia/Shanghai）。运行环境：PC 离线，源数据为 B-X02 的 export02 索引。

## 启动

在 `extensions/b_plus_v1/` 执行：

```powershell
python plus_app.py
```

打开 `http://127.0.0.1:8765/`。页面只读取归档留样，不访问板卡。

## 建议演示顺序

1. 默认选择 `long_hann_tone1k`，播放方式为“按原时间播放”，速度 20×；页面显示 frame 1、硬件 sequence 323、原始 elapsed_s 0.043 s。
2. 时间轴显示 14 个完整留样圆点；相邻留样之间标注“248 条指标”等缺口信息。缺口只显示说明文字，不绘制中间频谱。
3. 点击“下一份”：频谱切到 frame 250，瀑布新增一行“#02 / 原始时间”，缺口面板显示“该区间未留存完整频谱”。
4. 点击“暂停”：当前 frame_id、sequence 和 elapsed_s 不变；等待数秒后瀑布行数和统计不会增加。
5. 再点击“下一份”切到 frame 500，然后点击“播放”：按保存的留样顺序继续，直到 frame 3100 后显示“播放结束 · 未自动循环”，不会重复累计旧统计。
6. 切换到 `dual_rect`：瀑布、已展示统计和游标锁定全部清空；选择“等间隔浏览留样（非原始时间轴）”，界面保留原始 elapsed_s 标签，但播放间距改为等间隔。
7. 在任何模式中，来源徽标始终为 `REPLAY`；原始上下文固定显示为 `BOARD_LIVE`。

## 已生成的静态证据

- `player_initial.png`：Edge 无头浏览器实际渲染的初始页面，显示 REPLAY、frame 1、14 个时间轴留样点和缺口标注。
- `player_demo_complete.png`（如已生成）：使用 `?demo=1` 的等间隔快速演示，显示末尾“播放结束 · 未自动循环”和多行稀疏瀑布。
- `player_paused.png`（如已生成）：使用 `?demo=pause` 暂停在第二份留样，显示“已暂停 · 当前留样序号不变”。
- `player_dom.html`：同一页面执行 JavaScript 后导出的 DOM；包含 14 行留样列表，说明初始 frame 已通过 API 加载。
- `player_demo_dom.html`：完整演示的 DOM 证据，包含末尾状态和等间隔模式标签。
- `player_paused_dom.html`：暂停演示的 DOM 证据，包含 frame 250 和“已暂停 · 当前留样序号不变”。
- `manifest.json`：以上演示文件的逐文件 SHA256。

截图是初始状态证据，不是视频；上述步骤可在本地页面重复执行。

## 边界

- 长测 3100 条逐帧指标只有 14 份完整频谱；其余区间不能从指标行重建频谱。
- 瀑布按“留样序号 / 原始时间”标注，稀疏留样不等同于连续音频。
- 播放结束不会自动循环；再次播放是用户显式操作，并会开始新一轮统计。
- 本演示没有启动 Overlay、DMA 或 PYNQ 分配；`board_accepted` 仍为 `false`。

## 重新生成页面证据

启动服务后可使用无头 Edge：

```powershell
msedge.exe --headless=new --disable-gpu --no-sandbox `
  --virtual-time-budget=6000 --window-size=1440,1400 `
  --screenshot="reports\B-X03\player_initial.png" `
  "http://127.0.0.1:8765/"
```

快速完整演示（等间隔浏览器模式，明确标注非原始时间轴）：

```powershell
msedge.exe --headless=new --disable-gpu --no-sandbox `
  --virtual-time-budget=8000 --window-size=1440,1500 `
  --screenshot="reports\B-X03\player_demo_complete.png" `
  "http://127.0.0.1:8765/?demo=1"
```
