# B-X02 数据清单

生成日期：2026-10-31（Asia/Shanghai）。扩展：`b_plus_v1`。

## 来源

- 会话：`inputs_readonly/spectrum_session_a79f9a7236b2_export02.zip`
- 会话 SHA256：`3E7FFF49310213C024F073566E5420B5F69727BD9E9C225698B90D7272EBD62E`
- 原始模式/上下文：`LIVE/BOARD_LIVE`
- 实例：`instrument_a79f9a7236b2`
- 原始 run 总数：9；本轮选择：spectrum_569e5f254203, spectrum_f5953d8dcaa0, spectrum_38749b56cab6, spectrum_15131a729d8b
- 解析器：`fft_session.load_frame`，复用已保存 PL 复数结果，不重新做 FFT。

## 选中的 run

| 标签 | run_id | 场景 | 窗 | 目标频率/Hz | 指标行 | 完整频谱留样 | 时长/s | 序号范围 |
| --- | --- | --- | --- | --- | ---: | ---: | ---: | --- |
| long_hann_tone1k | `spectrum_569e5f254203` | tone1k | hann | 1000.0 | 3100 | 14 | 620.015 | 323..3422 |
| dual_rect | `spectrum_f5953d8dcaa0` | dual | rect | 1000.0, 3000.0 | 40 | 2 | 8.009 | 3423..3462 |
| dual_hann | `spectrum_38749b56cab6` | dual | hann | 1000.0, 3000.0 | 40 | 2 | 8.031 | 3463..3502 |
| analog_silence | `spectrum_15131a729d8b` | silence | hann | 无 | 40 | 2 | 8.014 | 3503..3542 |

总计：3220 条逐帧指标，20 份完整频谱留样。

## 留样 frame_id

- `long_hann_tone1k`：1, 250, 500, 750, 1000, 1250, 1500, 1750, 2000, 2250, 2500, 2750, 3000, 3100
- `dual_rect`：1, 40
- `dual_hann`：1, 40
- `analog_silence`：1, 40

## 两个数据集合

- `spectral_samples`：`sample_index.json` 内，共 20 条；每条含 words/state/fft 成员、SHA256、原 frame_id、原 sequence、原 elapsed_s 和加载边界。
- `metric_timeline`：`metric_timeline.jsonl`，共 3220 条；每条对应 `frames.jsonl` 的一行，保留逐帧 `metrics`。

## 验证结果

- 会话 SHA256、4 个 run 归档、4 个 run export manifest 均通过。
- `frames.jsonl` 行数与 summary 一致；保存留样数与 summary 一致。
- 已通过 `fft_session.load_frame` 解析 20 份完整频谱；保存的 `_fft.npy` 与解析结果一致 20 份。
- 序号连续性：全部选中 run 连续。

## 数据边界

- 长测的 3100 条指标不是 3100 份完整频谱；只保留了 14 份长测频谱。
- 其余 5 个 run（含两个早期 1 帧失败记录）保留在源会话中；本索引只选择四个代表性 run，不删除失败记录。
- 选中的四个 run 分开保存；不做跨 run、跨窗或不同频率网格的统计合并。
- 重复或内容恰巧相同的帧不去重；不同 frame_id 仍是不同观测。
- 原始采集为 LIVE；归档加载标记 REPLAY，不能当作新的板端采集。
- 幅值未做物理标定；board_accepted 仍为 false。

## 下一步

B-X03 可按 run 和 `saved_sample_frame_ids` 顺序播放留样；没有完整频谱的 frame 应显示“该区间未留存完整频谱”，不能从指标行插造频谱。
