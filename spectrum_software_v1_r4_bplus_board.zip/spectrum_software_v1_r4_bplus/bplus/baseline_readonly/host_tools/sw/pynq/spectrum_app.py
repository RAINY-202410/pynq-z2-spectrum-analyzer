"""Local browser instrument for PYNQ; standard-library HTTP, NumPy and existing driver."""
import argparse
import errno
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
import re
import secrets
import signal
from socketserver import ThreadingMixIn
import sys
from urllib.parse import urlparse

HERE = Path(__file__).resolve().parent
STATIC = HERE / 'spectrum_web'
if (HERE.parent / 'reference' / 'fft_contract_assets.py').is_file():
    sys.path.append(str(HERE.parent / 'reference'))

from spectrum_runtime import SpectrumRuntime
from spectrum_integrity import verify_software
from spectrum_recording import BUILD_REVISION


class ThreadedServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def make_server(runtime, bind='127.0.0.1', port=8091):
    token = secrets.token_hex(24)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send(self, data, content_type, status=200, filename=None):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            if filename:
                self.send_header('Content-Disposition', 'attachment; filename="' + filename + '"')
            self.end_headers()
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def json(self, value, status=200):
            self.send(json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8'), 'application/json; charset=utf-8', status)

        def do_GET(self):
            path = urlparse(self.path).path
            if path == '/api/status':
                self.json(runtime.status())
                return
            if path.startswith('/downloads/'):
                name = path[len('/downloads/'):]
                if not re.fullmatch(r'spectrum_(?:session_)?[0-9a-f]{12}_export[0-9]{2,}\.zip', name):
                    self.json({'error': 'Unknown export'}, 404)
                    return
                archive = runtime.downloads.get(name)
                if archive is None or not archive.is_file():
                    self.json({'error': 'Unknown export'}, 404)
                    return
                self.send(archive.read_bytes(), 'application/zip', filename=name)
                return
            assets = {'/': ('index.html', 'text/html; charset=utf-8'),
                      '/app.js': ('app.js', 'text/javascript; charset=utf-8'),
                      '/style.css': ('style.css', 'text/css; charset=utf-8')}
            if path not in assets:
                self.json({'error': 'Not found'}, 404)
                return
            name, mime = assets[path]
            content = (STATIC / name).read_bytes()
            if name == 'index.html':
                content = content.replace(b'__CONTROL_TOKEN__', token.encode('ascii'))
            self.send(content, mime)

        def do_POST(self):
            origin = self.headers.get('Origin')
            if (self.headers.get('X-Spectrum-Token') != token
                    or (origin and urlparse(origin).netloc != self.headers.get('Host'))):
                self.json({'error': 'Reload this instrument page before sending commands'}, 403)
                return
            try:
                length = int(self.headers.get('Content-Length', '0'))
                if not 0 < length <= 2_100_000 or self.headers.get_content_type() != 'application/json':
                    raise ValueError('Expected bounded JSON request')
                data = json.loads(self.rfile.read(length).decode('utf-8'))
                if not isinstance(data, dict):
                    raise ValueError('Expected JSON object')
                action = {'/api/start': 'start', '/api/stop': 'stop', '/api/render': 'render',
                          '/api/screenshot': 'screenshot', '/api/export': 'export',
                          '/api/export-session': 'export-session'}.get(urlparse(self.path).path)
                if not action:
                    self.json({'error': 'Unknown command'}, 404)
                    return
                # Compression and CRC checks on the board can exceed the control timeout.
                timeout = 300 if action in ('export', 'export-session') else 15
                self.json(runtime.call(action, data, timeout=timeout))
            except (ValueError, TypeError, RuntimeError, TimeoutError, KeyError) as error:
                self.json({'error': str(error)}, 400)

    server = ThreadedServer((bind, port), Handler)
    server.control_token = token
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('live', 'replay'), default='replay')
    parser.add_argument('--bind', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=8091)
    parser.add_argument('--bit', type=Path, default=HERE / 'fft.bit')
    parser.add_argument('--replay-folder', type=Path, default=HERE / 'replay_examples')
    parser.add_argument('--output', type=Path, default=HERE / 'spectrum_results')
    parser.add_argument('--allow-source-tree', action='store_true', help='Development only: permit a source checkout without a bundle manifest')
    args = parser.parse_args()
    identity = verify_software(HERE, args.allow_source_tree)
    runtime = SpectrumRuntime(args.mode.upper(), args.output, args.replay_folder, args.bit, software_identity=identity)
    try:
        server = make_server(runtime, args.bind, args.port)
    except OSError as error:
        runtime.close()
        if error.errno == errno.EADDRINUSE or getattr(error, 'winerror', None) == 10048:
            raise SystemExit('Port {} is already in use; this second service was not started. '
                             'Stop the existing spectrum service first; do not start another LIVE owner on a different port. '
                             'Use: python3 spectrum_service.py stop --port {}'.format(args.port, args.port))
        raise
    except BaseException:
        runtime.close()
        raise
    print('Spectrum instrument build=' + BUILD_REVISION + ' mode=' + args.mode.upper(), flush=True)
    print('Listening on {}:{}; open this computer/board address in your browser.'.format(args.bind, server.server_port), flush=True)
    print('LIVE hardware is configured once when Start is pressed. Keep other acquisition programs stopped.', flush=True)

    def interrupt(signum, frame):
        raise KeyboardInterrupt()

    signal.signal(signal.SIGTERM, interrupt)
    while True:
        try:
            server.serve_forever(poll_interval=0.2)
        except KeyboardInterrupt:
            try:
                runtime.close()
            except RuntimeError as error:
                print(str(error), flush=True)
                continue
            break
    server.server_close()


if __name__ == '__main__':
    main()
