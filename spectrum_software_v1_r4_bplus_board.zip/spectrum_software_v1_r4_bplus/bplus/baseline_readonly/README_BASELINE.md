# 只读基线

本目录保存从 r3 完整候选和配套操作包中提取的参考文件。除本说明外，所有文件按原字节复制，不得在此目录修改。

- 校验入口：上级目录的 `verify_baseline.py`
- 逐文件哈希：上级目录的 `BASELINE_MANIFEST.json`
- 原 r3 ZIP：`D:\AMD_competition\documents\B_拓展加分操作包_20261030.zip` 内 `baseline/A_spectrum_software_v1_r3.zip`
- r3 ZIP SHA256：`B9079BB1AD03A610AFB2BE3D5CD8A3323B329C8F61846EB375A1C149D0907AA5`

`host_tools/sw/pynq/fft_delivery.py` 和 `spectrum_sources.py` 含板上采集类定义，但模块导入本身不会访问板卡。扩展入口不得直接实例化 `FFTCapture`/`LiveSource`；实时订阅按 B-X08 的只读方案另行实现。

这里的 `package_manifest.json` 是 r3 原 manifest 的副本，用于逐文件来源核对，不是扩展自己的发布 manifest。
