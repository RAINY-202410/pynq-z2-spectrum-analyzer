# FFT 接口契约 v1.0：A侧技术冻结

版本：v1.0；冻结日期：2026-10-24（北京时间）。状态：**A_TECHNICAL_FROZEN**。用户已授权本步骤由A独立完成，A侧技术方案由Codex落实；B适配/签收另行记录，不作为A定稿前置条件。

已完成17项FFT设计参数回读、BD验证、模型生成和导出脚本的干净重建，窗/布局18项检查。另已运行同安装版官方FFT 9.1 C模型，25项检查通过，生成12组数值参考并固定验收规则。运行时配置握手、窗/打包/控制RTL、RTL数值对拍、DMA集成及板上验收仍待执行。证据见 [冻结记录](/D:/AMD_compitition/pynq-z2-spectrum-analyzer/docs/a_fft_freeze_20261024.md)。

本文是后续FFT版的实施与验收依据。现有M4硬件协议继续使用 `sw/pynq/README_M4.md`；M4验收产物保持不变。

## 1. 状态、范围与责任

- A：输入转换、窗、FFT IP、握手、输出打包、状态、硬件配置与仿真输出。
- A：同时提供冻结的六类输入、官方IP模型参考与数值比较入口，支持独立推进。
- B：按本版适配解析、幅值恢复、显示、误差表与材料；可另行复核参考模型。
- 本周范围：1024点、一路实数输入、矩形/对称 Hann、完整复数频谱、一次触发一帧。
- 配置中影响数值或协议的字段变更，先更新契约版本，再同步模型、向量和解析。
- 技术状态：DRAFT → A_TECHNICAL_FROZEN → SIM_VALIDATED → BOARD_ACCEPTED；B适配/签收单独跟踪。

当前A技术冻结已完成；B确认/适配结果未收到；RTL仿真与板上验收未完成。任何数值或协议变更须由A升版并更新参考、校验和及适配说明，不能静默修改v1.0。

## 2. A侧冻结的实施参数

| 项目 | 冻结值 | 当前依据或实施状态 |
| --- | --- | --- |
| 工具/器件 | Vivado 2026.1 / xc7z020clg400-1 | 运行预检已确认；正式工程须复核 |
| FFT IP | xilinx.com:ip:xfft:9.1 | 已按本版配置并生成模型 |
| N / 方向 | 固定1024、前向，不启用运行时变点数 | 固定点数已回读；前向配置字段已明确，握手未测 |
| 输入声道 | 固定左声道，暂不支持运行时切换 | A已定稿 |
| 输入格式 | 16位有符号、15个小数位，虚部恒0 | 官方C模型已按此运行 |
| 输入24转16 | 有符号算术右移8位，即 floor(s24/256) | A已定稿；边界检查通过 |
| 矩形窗 | 原值旁路，不经过近似1.0的系数乘法 | 待实现 |
| Hann | 对称窗，分母N−1 | A已定稿，使用实际系数文件 |
| Hann系数 | 16位无符号整数 c=round_even(w×32768)，范围0～32768 | 系数已生成、HEX/NPY读回一致，1.0精确可表示 |
| Hann乘积处理 | 使用足够宽的有符号正系数乘法，p=q16×c，z=floor(p/32768) | 不能将无符号 c 直接误当有符号16位；待 RTL/模型验证 |
| FFT架构 | Pipelined Streaming I/O，SSR=1，单通道 | 已回读；生成核心C_ARCH=3，资源/时序后续验收 |
| 等待模式 | Non-Realtime | 已回读且实际存在输入/输出TREADY；采集缓存/无丢样后续验证 |
| FFT数值模式 | 定点、固定缩放（Scaled） | 已回读；C_HAS_SCALING=1，C_HAS_BFP=0 |
| FFT舍入/旋转因子精度 | convergent_rounding / 16位 | 已回读，与输入量化/窗截位规则分开 |
| SCALE_SCH | 组0到组4右移3、2、2、2、2，总S=11；字段0x2AB | 依据PG109和实际配置口计算；运行时握手未测 |
| 输出顺序 | 自然序 k=0～1023 | 已回读natural_order；C模型自然输入/输出、bin16符号检查通过；RTL待测 |
| FFT实部/虚部数值位宽 | 各16位，15个小数位，原生TDATA32位 | 已查生成端口及C_OUTPUT_WIDTH=16 |
| DMA流宽 | 64位，一拍一个复数频点 | A已定稿，需后续包装/连接验证 |
| DMA方向 | 仅S2MM | 新版hwh应确认无MM2S需求 |
| 包长 | 1024拍×8字节=8192字节 | 与旧M4相同字节数但含义不同 |
| 时钟 | PL100MHz；实际采样率单独记录 | 100MHz不是fs；频轴使用本次实测fs |
| 跨包连续性 | 单帧快照，帧间允许空隙 | 不能登记为无间隙连续音频 |

机器可读冻结配置见 `hw/ip/fft_contract_v1.json`，17项原始回读和端口快照保留在 `hw/ip/fft_contract_v02.json`。复用已验证的 `hw/ip/fft_contract_v02_bd.tcl`，静态参数未变。原始证据在 `build/fft_contract_20261024_01/`；本次数值参考核验在 `build/fft_freeze_20261024_01/`。

## 3. 输入与窗的数学规则

真实采集路径：

```text
s24：有符号24位音频，原始双声道仍按M4保存
q16 = floor(s24 / 256)          # 有符号算术右移8位
x = q16 / 32768
w[n] = 0.5 - 0.5*cos(2*pi*n/1023), n=0..1023
c[n] = round_to_nearest_ties_to_even(w[n]*32768)
矩形：z[n] = q16[n]
Hann：z[n] = floor(q16[n]*c[n]/32768)
FFT实际输入：实部z[n]，虚部0
```

例：s24=256→q16=1；s24=−1→q16=−1。算术右移与向零取整不同，B 模型必须使用同一规则。

B 的数字 Q1.15 黄金向量在 q16 边界注入，不再右移8位。若要走完整24位转换路径，可以构造 s24=q16×256，再执行转换。B 原有从浮点生成 q16 的就近舍入属于上游向量生成，不等同于真实采集的24转16操作。

Hann有效窗增益按量化系数记录：`window_sum=sum(c)/32768`。FFT数值对拍的参考应使用实际 z[n]/32768；仅使用浮点 w 的参考另标为浮点窗诊断参考。窗乘法截位误差不能被错误归给 FFT。

冻结窗数据位于 `sim/vectors/fft_contract_v1/`；其中旧window_manifest的A_PREPARED字段是生成当时的历史状态，当前冻结状态以本文和 `hw/ip/fft_contract_v1.json` 为准：

- `hann_coeff_u16.npy`：1024个uint16系数，SHA256 `BACC802AC2A4DFC905EE7551C1DC404268BA42A435D3ADCE2C9D5F3D8D6B5B23`。
- `hann_coeff_u16.hex`：每行一个16位值，SHA256 `795D500FC0B0C0C176B896BE7BA48CDCE473A092D517003C1EB5D7DF358658D3`。
- 整数系数和16760834；`window_sum=511.50006103515625`；矩形窗window_sum=1024。
- 生成/核验入口：`sw/reference/fft_contract_assets.py`；完整信息在 `window_manifest.json`。B应复用文件，不自行生成不同量化规则的表。

## 4. 输出布局

每个频点一个64位AXIS数据拍：

| 位段 | 内容 |
| --- | --- |
| [31:0] | FFT 16位实部符号扩展为32位槽 |
| [63:32] | FFT 16位虚部符号扩展为32位槽 |

小端存储；32位槽只是存储宽度，数值小数位仍为15。例：实部−1、虚部2时，64位字为 `0x00000002FFFFFFFF`；int32视图依次应为−1、2。

- 输出完整1024个频点，B显示时提取0～512的单边谱。
- TKEEP=0xFF；第1024个实际输出握手携带TLAST；计数与元信息随背压保持稳定。
- DMA缓冲按本布局为8192字节，但不能调用M4的左右声道解码把它当时域音频。
- 不在数据包中插入额外包头/状态字。若后续要添加，需重新定义包长及解析。
- 实际hwh、DMA名称/基地址、版本寄存器回读、正式bit/hwh哈希：后续实现/构建时填写，当前尚无这些FFT产物。

## 5. 缩放与幅值恢复

本版选用组0到组4右移3、2、2、2、2，总S=11。S不包含输入Q1.15的15个小数位，也不重复计入窗处理。已用官方C模型按此表生成12组参考；FFT RTL握手及数值仿真留待第三步。

本次生成配置口确认为16位：bit0为FWD_INV=1；[10:1]为SCALE_SCH=0x2AB；[15:11]=0，因此完整配置字为 `16'h0557`。FWD_INV后没有独立的字节填充，不能拼成0x2AB01。该编码已做字段拆装检查，实际配置握手尚未执行。

本版16位/15小数位固定缩放整数yr、yi统一恢复尺度：

```text
Y = yr + j*yi
X = (Y / 32768) * 2**S
```

此 X 对应归一化输入经实际窗处理后的未缩放前向 FFT 的近似值。单边幅值先 `abs(X[:513])/window_sum`，中间正频点乘2，DC/Nyquist不乘2，再按峰值满量程基准转 dBFS。缩放仅恢复一次。

PG109对1024点Pipelined Streaming I/O给出了保守表 `[10 10 10 10 11]`（组0在低位，对应移3、2、2、2、2位，总S=11）。本版据此固定缩放；字段已核验，实际配置握手留待RTL仿真。其他架构须另查缩放表，整个配置TDATA不能写成单独SCALE_SCH字段。[PG109缩放说明](https://docs.amd.com/r/en-US/pg109-xfft/Pipelined-Streaming-I/O-Architecture)

采样率来源：新版会话的实际fs；频率 `f[k]=k*fs/1024`。历史47998.71Hz是已有会话记录，不是以后每帧的固定事实。

## 6. 控制与状态语义：A已冻结，RTL待实现

以下逻辑接口由新版 `fft_ctrl_0` 提供，实际IP基地址在后续从hwh读取。此表仅用于未来FFT版，当前M4继续按其README操作；下列寄存器尚未实现。

| 偏移 | 名称 | 读写 | 冻结行为 |
| --- | --- | --- | --- |
| 0x00 | COMMAND | 写1触发命令，读0 | bit0 START；bit1 ABORT；bit2 CLEAR，均单周期请求 |
| 0x04 | WINDOW | RW | bit0：0矩形、1Hann；帧开始锁存，忙时写入供下一帧使用 |
| 0x08 | STATUS | RO | bit0 busy；bit1 input_done；bit2 output_done；bit3 input_overflow；bit4 fft_overflow；bit5 tlast_missing；bit6 tlast_unexpected；bit7 start_ignored；bit8 config_done；bit9 aborted |
| 0x0C | LENGTH | RO | 固定1024，不提供运行时变长 |
| 0x10 | VERSION | RO | 0x46465401，表示FFT协议第1版 |
| 0x14 | INPUT_COUNT | RO | 本帧实际FFT输入握手计数，0～1024 |
| 0x18 | OUTPUT_COUNT | RO | 本帧实际频谱输出至打包/DMA侧的握手计数，0～1024 |
| 0x1C | FRAME_SEQUENCE | RO | 每次接受START时加1，32位自然回绕 |

软件每次写一个命令；多位同时写的硬件优先级ABORT>CLEAR>START。START仅在空闲且config_done时接受，否则不排队并置start_ignored。新帧开始清本帧计数、done和错误；FRAME_SEQUENCE单独累计。保留位读0、写忽略；RO寄存器写忽略，WINDOW仅bit0有效。

ABORT停止取样/清理流水线，FFT复位至少4个100MHz周期，清config_done后自动重新提交固定配置0x0557，握手后config_done置位。它不代替软件侧DMA复位或清除codec配置；恢复流程继续先中止PL，再确保DMA停止。CLEAR只在空闲时清本帧计数/done/粘滞诊断，不改窗口、FRAME_SEQUENCE或有效FFT配置。

busy从接受START开始，直到1024个输出拍全部被下游接受且本帧FFT状态拍已接收/锁存后才清零。input_done在第1024个FFT输入握手置位，output_done在第1024个64位DMA侧输出握手置位；两者保持到新START或空闲CLEAR。ABORT清busy并置aborted，保留截至中止时的计数/done/诊断供软件取证；新START或空闲CLEAR清aborted。忙时CLEAR忽略。复位将计数、状态、序号及WINDOW清0，然后自动配置FFT。

1. 空闲时选择窗口，清理旧状态；帧开始锁存窗口，本帧中途改写不影响当前帧。
2. 复位/中止后，等待流水线与DMA回到已定义的可重启状态。
3. 完成FFT配置握手，接收缓冲和S2MM武装完成后才允许触发采集。
4. 同时只允许一帧在途；忙时再次START忽略、不另排队并置start_ignored，在RTL验收覆盖。
5. 区分 input_done、FFT输出发完、DMA完成；软件成功需帧结束、点数/字节数、DMA与PL状态共同满足。
6. 超时、输入丢样、FFT溢出、帧事件错误均保留日志并判该帧失败；停止和重新武装须有明确流程。
7. FFT TLAST事件可能晚于相关输入拍，应覆盖到帧处理完成再读取/锁存，不只在输入最后一拍检查。

本次实际FFT产生m_axis_data_tuser[7:0]、m_axis_status_tdata[7:0]，当前选项下OVFLO在bit0。上层应持续接收状态通道并锁存溢出/帧错误，不能因状态口未准备好阻塞IP。event_frame_started仅作诊断；Non-Realtime的通道halt信息应结合握手分析，不独立作为数据已损坏的证据。STATUS的output_done仅表示末拍被下游接收，软件成功仍需等待DMA完成并核验长度与错误。

## 7. 冻结的数值参考与验收规则

六类同输入、矩形/Hann共12个主干组合，保存完整1024点复数参考，直流用例不去均值。n=0..1023，数字向量统一q16=round_even(x*32768)，s24=q16*256；实际采集仍按第3节右移8位。

| 名称 | 归一化输入x |
| --- | --- |
| zero | 全0 |
| dc | 恒定0.25 |
| impulse | n=512为0.5，其余0；保证Hann下仍有有效脉冲 |
| bin16 | 0.5*sin(2*pi*16*n/1024) |
| bin16p35 | 0.5*sin(2*pi*16.35*n/1024) |
| bin16_bin70 | 0.25*sin(2*pi*16*n/1024)+0.125*sin(2*pi*70*n/1024) |

A已生成输入与参考，位于 `sim/vectors/fft_golden_v1/`，以文件及reference_manifest中的SHA256为准。入口 `sw/reference/fft_contract_reference.py`：本机Vivado 2026.1安装所带xfft9.1 Windows x64 C模型已实际运行。模型参数为NFFT_MAX=10、ARCH=3、HAS_NFFT=0、USE_FLT_PT=0、INPUT_WIDTH=16、TWIDDLE_WIDTH=16、HAS_SCALING=1、HAS_BFP=0、HAS_ROUNDING=1、NSSR=1，方向1，五组缩放[3,2,2,2,2]。

1. 预处理：RTL输出q16/z与文件中的对应整数逐点一致；系数与冻结文件一致。
2. FFT数值：同一z输入，1024个自然序复数的实、虚整数分别与官方模型一致。允许差异组件数=0，最大组件误差=0整数LSB；不自动拟合增益、偏移或频点重排。模型double输出精确乘32768还原整数，不再补缩放后比较。
3. 帧有效性：模型与RTL均无溢出，输入无丢样，TLAST无异常；配置先握手完成。计数各1024，64位包8192字节、TKEEP/TLAST及背压保持符合第4/6节。数值一致而帧/协议失败，整项仍失败。
4. 硬件时序与恢复：下一阶段覆盖输入间歇、输出背压、忙时START、ABORT/重新配置/重新武装、窗口帧锁存，分别留日志；C模型不覆盖这些行为。
5. 浮点诊断：使用同一z的 `numpy.fft.fft(z/32768)`，对恢复尺度X计算最大复数绝对误差、复数RMSE及非零参考相对L2。只报告诊断值，不作本版通过阈值，不用浮点容差替代整数不一致。

每个case的 `reference.npz` 保存input_s24/int32、input_q15/int16、fft_input_z/int16、expected_real/imag/int16、expected_words/uint64和diagnostic_float_fft/complex128。`input_q15.hex` 为1024行四位二补码十六进制，供RTL加窗前输入；`expected_words_u64.npy` 为1024个小端uint64。新采集/RTL输出按同格式保存后使用compare入口数值核对；状态、握手和长度仍需单独核验。

A后续交付另须包含实际RTL输出、状态、日志及硬件版本，不能以官方模型参考文件冒充PL输出。B可直接复用冻结输入、参考、解包函数和幅值规则进行适配；B独立复核、显示和板上签收另行推进。

依据：官方PG109说明定点输入须预量化，Scaled输出保持输入小数精度，流水架构溢出时模型输出可能与RTL不一致且须忽略。[PG109定点模型](https://docs.amd.com/r/en-US/pg109-xfft/FFTs-with-Fixed-Point-Interface)；本次自然序输入按模型同序输出规则处理。[PG109模型数组与顺序](https://docs.amd.com/r/en-US/pg109-xfft/General?contentId=2cmc5DiR5xfY3BCh6hJn2Q)

## 8. A侧冻结清单与后续门槛

- [x] A授权独立定稿，范围、输入转换、窗数学、乘积处理与输出布局完整。
- [x] ROSS保存实际设计参数、输出顺序、接口宽度；运行时缩放编码已准备，握手测试另列待办。
- [x] A侧控制/状态表、忙时触发和恢复语义完整；实际RTL实现待办。
- [x] 实际系数文件、校验和及window_sum一致。
- [x] 数值验收采用已运行的匹配官方模型；0整数LSB、零差异组件、无溢出；浮点诊断不设任意阈值。
- [x] 六类输入/两种窗、同输入文件格式、模型来源与文件哈希固定。
- [x] 冻结为v1.0/A_TECHNICAL_FROZEN；最终文件SHA256由独立manifest记录，避免在文件中自引用。

第二步到此完成。第三步须生成真实RTL输出并通过上述12组数值/协议回归，之后才登记SIM_VALIDATED；后续构建填新版bit/hwh、基地址和实际哈希，再按板上证据登记BOARD_ACCEPTED。B适配/签收当前仍未确认。
