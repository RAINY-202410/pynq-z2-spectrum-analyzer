# r2整会话export02核验与软件推进

日期2026-10-30，北京时间。状态 **BOARD_UI_LONG_RUN_VALIDATED_DISPLAY_REVIEW_PENDING**。用户授权本轮一并完成原B软件及材料任务；实际接线、播放、供电和上板由用户执行。

## 本次有效结论

用户原件`spectrum_session_a79f9a7236b2_export02.zip`为1970216字节，SHA256 `3E7FFF49310213C024F073566E5420B5F69727BD9E9C225698B90D7272EBD62E`。可信审计器独立核验，未执行收到的代码。实例仍为`instrument_a79f9a7236b2`，来源BOARD_LIVE，软件`spectrum_software_1_r2`及冻结bit/hwh一致。

- 9次运行、3542帧、28份原始留样、11张界面图；7次功能运行通过，2次早期1帧单音诊断失败保留。9次均安全停止。硬件序号从0累积至3542，未通过改数据或排除失败包来收尾。
- 长测`spectrum_569e5f254203`：Hann、在线tone1k、620.01506344秒/3100帧、DURATION_COMPLETE、逐帧单音观察通过、安全停止；快照4.999878524 Hz。
- 双音矩形`spectrum_f5953d8dcaa0`与Hann`spectrum_38749b56cab6`各40帧；1k/3k观测频点984.345659754/2999.910582106 Hz，各声明频率检查通过。模拟静音`spectrum_15131a729d8b`40帧通过记录。
- 实测fs47998.569313695836 Hz，bin宽46.87360284540609 Hz。单音主峰中位-12.93601024 dBFS，3100帧跨度0.031288915 dB。未做绝对电压标定。
- 2次早期失败`spectrum_d52a510b59ba`、`spectrum_5e2dddafad39`在单音检查失败后均安全停止；主峰46.8736 Hz/-66.2181 dBFS，与未检测到有效1kHz输入一致，但具体物理原因未单独实证。后续长测有效结论保持。

## 保留的显示与资源缺项

长测有3096条浏览器绘制回执、4.993195485 Hz，canvas均值1.200710594 ms、P95约1.4 ms。约第436.917881秒和437.909845秒有两条visible=false回执，最长连续前台段436.534002463秒，不能登记连续600秒显示通过。采集完成620秒与前台连续显示是两个独立结论。审计状态SESSION_DATA_VERIFIED_REQUIREMENTS_PENDING、visible_ui_10min=false正确保留，未放宽要求。

22个长测资源点中RSS72978432字节恒定，FD17降至15；全局CmaFree70852608降至66707456字节，净减4145152字节（3.953125 MiB），期间两次回升。没有分配来源证据，保留cma_review_pending=true，不宣称已定位泄漏或无泄漏。提供独立只读proc观察器供下一轮补RSS/PSS/FD/缓存/CMA，未修改运行驱动。

采集调用均值35.251612371 ms、P9557.192492650 ms、最大69.137342 ms；PS分析均值6.918548189 ms、P957.568790 ms。浏览器计时与采集分别记录，未测同步端到端延迟。

## 本轮一并完成的软件与B工作

- 全部数据独立审计及频率、幅值、噪声观察、性能、资源、条件、问题与逐文件SHA256索引；四类历史单音/音量数据独立列示，不混作新UI实测。历史2kHz降音量幅值比0.09075256/-20.84282 dB。
- 真实执行HOST_PC同输入12类FFT基准，每类预热20次、20批×500次；均值8.98501至9.27658 µs，全部同输入浮点结果核对通过。P95为批均值百分位。ARM端、纯PL延迟和加速比尚无实测结论。
- 8页DOCX、PDF、Markdown候选报告、3幅实测图、r2候选README/环境/问题表、B任务完成对照及本地候选材料包。
- 原r2板端ZIP干净目录解压、35文件/Notebook身份及7类真实留样REPLAY核验通过。未新建独立依赖环境或访问硬件。
- 独立只读proc/boot身份工具，Python3.6语法、模拟proc及原r2软件身份检查通过；实际Linux执行待用户。33分钟真实WAV已生成并核验头/首尾/频率/哈希，仅放PC。
- LIVE演示分镜、录制操作说明和字幕草稿已备；未虚构真实视频、物理冷启动、签收或正式提交。

详细B-W06至B-W16及B6对应关系见[B任务完成对照](B任务完成对照_20261030.md)。B-W09、已有证据范围的B-W10、候选B-W12、B-W14报告候选稿及B-W16本地候选包已完成；B-W11完成数字参考与PC基准，B-W13准备完成、实际板测待做，B-W15脚本完成、实录待做。

## 当前产物与接续

- 原始审计和统计：`build/spectrum_board_validation_20261030_02/`；报告数据receipt为`report_data/validation_receipt.json`。
- 材料包：`release/spectrum_validation_20261030/A_B_software_review_20261030.zip`，14243689字节，242文件，SHA256 `9AC8A03E4D5B3FFCD82CAB98FF05FDB98F778E36DC99225726B09CCBB05DF56A`；CRC与全部manifest哈希通过。
- 报告：同目录解压树`A_B_software_review_20261030/report/`，8页最终渲染逐页检查通过。
- 独立板端工具ZIP：`release/spectrum_validation_20261030/spectrum_validation_board_tools_20261030.zip`，SHA256 `3C5A49D91A65FB87CFE46AD99D0208E9242B6BB97D68BA8CE185AEB89275DE95`。
- 电脑音频：`release/spectrum_validation_20261030/PC_audio/sine_1000Hz_1980s.wav`，33分钟/380160044字节，SHA256 `52A68AF4BA0FBBD1CAD2A85F1A2784C150C13F172691E0CA25BB74924A54C866`。软件ZIP不含WAV，不上传板卡。

下一次按[下一轮板测操作单](下一轮板测_20261030.md)：保留r2服务，独立1900秒资源观察，电脑播放33分钟单音，Hann/tone1k/1820秒/5Hz连续前台，随后同服务20秒恢复，返回新整会话ZIP和资源JSONL。采集停止后运行ARM基准；再另做三次实际冷启动短测。无需重跑已通过的双音/静音或旧Notebook。

board_accepted=false保持。物理标定、THD/SNR、同步延迟和完整外部I/O时序仍按既有边界；旧RTL/软件/ZIP和27个M4保护文件保留，本轮未重建硬件、改目录名或删除板端文件。
