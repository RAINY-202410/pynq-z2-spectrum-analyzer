# 项目交接说明：PYNQ-Z2 实时频谱分析仪

原始交接核对时间：2026-10-22 21:24；最新增量更新：2026-10-30（Asia/Shanghai，北京时间）。

## 当前交接快照（继续工作先读本节）

**新对话入口：先读[本轮接续与文件回传清单](pynq-z2-spectrum-analyzer/docs/新对话接续_20261030.md)。用户当前要找本轮结果交回核验；下一步是取回文件，不是再跑30分钟。最新Jupyter根目录截图已显示救援脚本、r2目录、资源工具目录和CPU工具目录，实际生成结果仍需进入子目录/读脚本输出核对。**

**最新操作反馈：用户已确认导出报Worker command still pending。** r2默认15秒命令等待已超时，后台任务未被取消，尚待目录/CRC确认ZIP是否最终完成。先按[导出恢复步骤](pynq-z2-spectrum-analyzer/docs/spectrum_export_recovery_20261030.md)检查现成ZIP或保全原始数据，不重跑长测、不停止服务。已另备[r3导出修复候选](pynq-z2-spectrum-analyzer/docs/software_export_hotfix_r3_20261030.md)：HTTP两种导出等待300秒，其他控制仍15秒；34项HOST及干净包7类REPLAY/导出/审计通过，27项M4/RTL/契约及硬件不变。实际板端仍r2，先收到并核验当前数据再安排切换。

**状态：`BOARD_UI_LONG_RUN_VALIDATED_DISPLAY_REVIEW_PENDING`。** 当前依据为用户export02和本节最新审计。620秒在线单音采集、双音两窗、静音及停止恢复通过；连续前台600秒及CMA归因尚未闭环。`board_accepted=false`保留。历史“待首次上板”“需再跑双音/静音”不作为当前待办。

### 1 工作区与分工

- 工作区`D:\AMD_compitition`，主工程`D:\AMD_compitition\pynq-z2-spectrum-analyzer`。外层目录未改名，避免破坏Vivado绝对路径。
- 用户负责接线、播放、实际板测、关机供电和返回文件；Codex负责软件、核验、指标及材料。用户本轮明确授权连同此前B的任务直接完成，不再以等待B为软件推进前置条件；不虚构B本人签收。
- [原B后续计划](pynq-z2-spectrum-analyzer/docs/B后续操作步骤_20261029至1101.md)保留。当前实际完成情况见[B任务对照](pynq-z2-spectrum-analyzer/docs/B任务完成对照_20261030.md)。

### 2 当前有效进度

| 工作块 | 当前结论 |
| --- | --- |
| 冻结FFT 数值与硬件 | FFT v1.0，12主例+2恢复例、真实RTL对官方模型0整数差异；bit/hwh及27个M4保护项保持；外部I/O时序限制保留 |
| 原驱动长跑 | 600秒3000帧、停止恢复、双音静音、完整Notebook有效；空闲120秒JSONL已补齐；CMA来源仍待查 |
| 基础软件 | r2频谱/瀑布、LIVE/REPLAY、窗/峰值、有限留样、导出与独立审计已完成；既有28项主机检查保持有效 |
| r2此次实板 | 9次3542帧、7次功能运行；28原始留样/11界面图；9次安全停止；620.015秒3100帧在线单音、双音两窗和静音通过 |
| 显示缺项 | 长测约437秒两条隐藏回执；最长连续可见436.534秒，未达600秒；采集结果仍有效 |
| 指标与B材料 | 实测表/3图/12类PC基准/8页DOCX PDF报告/README 环境 问题 索引/演示分镜与字幕/本地候选包已备 |
| 发布进展与未核验 | 用户反馈约30分钟抽查正常，本轮原件待取回；实际时长/前台/20秒恢复及ARM、三次冷启动、CMA、真实录像与最终验收仍待证据 |

固定xc7z020clg400-1、左声道1024点；LINE IN→codec/I2S→PL窗/FFT→64位复数/S2MM→PS幅值/峰值→浏览器。PS不二次FFT。自然序、低32real/高32imag各signed16符号扩展，S=11恢复后分别除16；单边中间点乘2，矩形窗和1024、Hann511.50006103515625。协议0x46465401、8192字节/帧，快照允许帧间间隙。

### 3 最新实测与归档

- 原件`spectrum_session_a79f9a7236b2_export02.zip` SHA256 `3E7FFF49310213C024F073566E5420B5F69727BD9E9C225698B90D7272EBD62E`；同实例`instrument_a79f9a7236b2`，BOARD_LIVE/r2，可信审计为SESSION_DATA_VERIFIED_REQUIREMENTS_PENDING。
- 长测`spectrum_569e5f254203` Hann/tone1k：620.01506344秒/3100帧/4.999878524 Hz，在线检查逐帧通过，DURATION_COMPLETE，安全停止。fs47998.569313695836 Hz；主峰bin21/984.345659754 Hz，中位-12.93601024 dBFS。
- 双音矩形`spectrum_f5953d8dcaa0`、Hann`spectrum_38749b56cab6`、静音`spectrum_15131a729d8b`各40帧通过。两段早期1帧单音失败保留，均安全停止，未单独实证物理原因。
- 长测浏览器3096回执/4.993195485 Hz，最长连续可见436.534秒。RSS72978432字节恒定，FD17→15，全局CMA70852608→66707456字节，净减3.953125 MiB且两次回升，不能据此宣布泄漏或无泄漏。
- 板端Python3.10.4、NumPy1.21.5、PYNQ3.1.1、Linux6.6.10-xilinx-v2024.1。PC完整12类同输入FFT每类20×500调用，均值8.98501～9.27658 µs；与capture调用不是同计时范围，不报告加速比。
- [详细核验](pynq-z2-spectrum-analyzer/docs/a_spectrum_export02_20261030.md)，审计`build/spectrum_board_validation_20261030_02/audit.json`，新receipt为同目录`report_data/validation_receipt.json`。

| 用途 | 当前文件 |
| --- | --- |
| 现有板端软件 保持r2 | [spectrum_software_v1_r2_board.zip](pynq-z2-spectrum-analyzer/release/spectrum_software_v1_r2/spectrum_software_v1_r2_board.zip) |
| 最新结果及B材料包 | [A_B_software_review_20261030.zip](pynq-z2-spectrum-analyzer/release/spectrum_validation_20261030/A_B_software_review_20261030.zip) |
| 当前下一步 取回本轮文件 | [新对话接续与回传清单](pynq-z2-spectrum-analyzer/docs/新对话接续_20261030.md)；[导出恢复](pynq-z2-spectrum-analyzer/docs/spectrum_export_recovery_20261030.md) |
| 已执行轮次的原操作说明 | [下一轮板测](pynq-z2-spectrum-analyzer/docs/下一轮板测_20261030.md)，不据本页重跑 |
| r3后续候选 尚未部署 | [r3修复说明](pynq-z2-spectrum-analyzer/docs/software_export_hotfix_r3_20261030.md)；先保全r2数据 |
| B已完成及剩余 | [B任务完成对照](pynq-z2-spectrum-analyzer/docs/B任务完成对照_20261030.md) |
| 机器状态 | [current_status.json](pynq-z2-spectrum-analyzer/build/fft_delivery_20261024_v1/current_status.json) |

原r2板端ZIP SHA256 `D6F01E440CB184AD08E052A6A9C0789B7EA7CCFF0FA6EEA34A087E2DFDD51E1A`，manifest `E1A84240287AF06490C8B4144E94E5A8D21A205913CEDB8F9FA22FEC08D6CCBA`。原软件包不变，新增独立只读观察/boot工具不覆盖r2。

用户最新口头反馈：不定时抽查约30分钟内频谱显示正常；尚未收到这轮原始ZIP，正式30分钟、连续前台及恢复验收保持待核验，当前不要求重复长测。

### 4 下一步实际动作

1. 保留现有r2服务和原始数据；确认采集已停止，不继续点网页导出，不先升级、重启或清理。当前只拿回已有结果，不再安排一次30分钟。
2. 用户截图已显示根目录有`spectrum_export_rescue.py`。第二终端运行`cd /home/xilinx/jupyter_notebooks`及`python3 spectrum_export_rescue.py`，读出完整ZIP路径和CRC。
3. 有包含本轮长测/恢复且CRC通过的`spectrum_session_...zip`，直接通过Jupyter下载；默认位置为`spectrum_software_v1_r2/spectrum_results/`。没有完整ZIP时运行`python3 spectrum_export_rescue.py --backup`，下载根目录新生成的`spectrum_rescue_...zip`。救援备份不是原生会话格式，收件后先核验救援manifest再恢复审计。
4. 一并返回观察器`spectrum_resources_*.jsonl`，通常在`spectrum_validation_board_tools_20261030/`，以终端Output为准。若已执行ARM基准，返回`b_cpu_benchmark_20261029_1101/`中的`cpu_fft_arm_20261030.csv`和同名JSON；未执行先不阻塞现有结果取回。三次冷启动结果仅在实际做过时回传，不推定已完成。
5. 新对话Codex新建审计目录，核对实际≥1800秒、连续前台、逐帧质量/状态、停止和20秒恢复、CMA与ARM结果，再决定实际剩余项和r3安全切换。不默认重跑双音/静音或30分钟。

截图中的旧修改时间不能用于判断本轮日期。文件清单、具体路径及可复制命令见[接续操作单](pynq-z2-spectrum-analyzer/docs/新对话接续_20261030.md)。不需要用户回传安装包、音频或整个Jupyter目录；已收到的PNG不要求重复发送。用户负责实际板卡操作，Codex继续一并承担原B软件和材料工作。

### 5 B工作与边界

- B-W06本轮矩阵、B-W08等价阶段材料、B-W09基线、B-W10已有证据指标整理、B-W12候选版本说明、B-W14候选报告、B-W16本地内审包已完成。
- B-W07已完成620秒采集/性能资源统计，前台600秒和CMA未关闭；B-W11完成14例参考引用与PC基准，ARM及同口径硬件性能待补；B-W13工具/音频/操作准备完成、实际发布回归待做；B-W15完成分镜/字幕/离线复现步骤，真实录屏和独立依赖环境复现仍未完成。
- B6-01有指标和报告候选稿；B6-02有固定r2、README/环境/问题表与本地候选包；B6-03有脚本/字幕/素材结构，未虚构最终录像、对外提交或B签收。
- CMA、物理电压、THD/SNR、纯PL/同步端到端延迟、完整外部I/O时序独立跟踪。DDS/RC及独立PS GUI补建为后续条件项。旧ZIP、RTL、原始失败记录不改；不放宽断言/修改manifest收尾。
- 板端清理仍待完整目录及备份核对，未删除文件；外层目录未改名。没有新权限/确认流程或外部发信。

