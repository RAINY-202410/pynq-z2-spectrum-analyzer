# r3导出等待修复候选

先读RECOVER_CURRENT_R2.md，取回当前r2原始证据后再安排切换。不要现在停止服务或替换运行文件。

本版仅将HTTP导出等待设为300秒，其他控制仍15秒；硬件、数值、采集运行与前端不变。34项主机检查、干净目录7类REPLAY/导出/审计通过。尚未实际LIVE板测。

部署用spectrum_software_v1_r3_board.zip完整解压新目录，按HOTFIX_R3.md安全切换。旧r2结果保留，旧r2_validation/previous_v1_reports及HOTFIX_R2.md是历史记录。
