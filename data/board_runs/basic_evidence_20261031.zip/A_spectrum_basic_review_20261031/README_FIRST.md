# 基础功能复核包（含未关闭项）

先读 docs/a_spectrum_basic_review_20261031.md 和本轮 basic_review_receipt.json。
当前板端r3已部署并通过短测及三次实际冷启动；r2长测保持原版本归属。
原始ZIP/JSON/CSV、用户实际断电上电确认、审计记录与逐文件哈希清单均在包内。
release/spectrum_software_v1_r3/ 中是未修改的原板端安装ZIP，不需要重复安装。
冻结软件receipt里的HOST/BOARD_PENDING是包生成时历史状态，以本包新核验页为准。
CMA来源仍待查，真实LIVE录像及最终DOCX/PDF未完成，board_accepted=false。
这是本地复核交付，未对外提交，不是全部项目最终验收；不重复已通过的板测。
审计脚本复跑需要完整主工程与NumPy，本包不声称附带独立Python运行环境。
