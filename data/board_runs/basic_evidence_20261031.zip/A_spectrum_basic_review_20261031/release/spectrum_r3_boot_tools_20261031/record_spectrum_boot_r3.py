"""Record r3 boot identity; reads files/proc only, never imports PYNQ."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import uuid

MANIFEST_SHA256 = '7F1DA7D0BA2CE892CA3A318D0DE76360075FDA2545198EE374D614E0765662A5'
HARDWARE_SHA256 = {
    'fft.bit': 'A00606402E7ADC8929DEDA61FFAD39236AD3500FF87976E001292A6078551E26',
    'fft.hwh': 'A4F43CC8594ECCCD6F30B43E5BFC935DDFA0F2825AD90C1D9F659B5DE1DCE091',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def record(base, label, proc_root=Path('/proc')):
    base = Path(base).resolve()
    manifest_path = base / 'software_manifest.json'
    if digest(manifest_path) != MANIFEST_SHA256:
        raise ValueError('Expected the frozen r3 software manifest; do not edit the manifest')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest['build_revision'] != 'spectrum_software_1_r3':
        raise ValueError('Expected r3 build identity')
    for name, expected in manifest['files_sha256'].items():
        path = (base / name).resolve()
        path.relative_to(base)
        if digest(path) != expected:
            raise ValueError('Package source differs: ' + name)
    hashes = {name: digest(base / name) for name in ('software_manifest.json', 'fft.bit', 'fft.hwh', 'spectrum_app.py')}
    if any(hashes[name] != expected for name, expected in HARDWARE_SHA256.items()):
        raise ValueError('Hardware differs from frozen v1.0')
    notebook_path = (base / manifest['notebook']).resolve()
    notebook_path.relative_to(base)
    notebook = json.loads(notebook_path.read_text(encoding='utf-8'))
    count = manifest['notebook_cell_count']
    if len(notebook['cells']) < count:
        raise ValueError('Launcher Notebook is incomplete')
    for cell in notebook['cells'][count:]:
        if ''.join(cell.get('source', [])).strip() or cell.get('outputs'):
            raise ValueError('Unexpected nonempty extra Notebook cell')
    source = [(c['cell_type'], ''.join(c['source']), c.get('metadata', {}).get('tags', []))
              for c in notebook['cells'][:count]]
    source_hash = hashlib.sha256(json.dumps(source, ensure_ascii=False).encode('utf-8')).hexdigest().upper()
    if source_hash != manifest['notebook_source_sha256']:
        raise ValueError('Launcher Notebook source differs from frozen r3')
    return dict(context='BOOT_IDENTITY_RECORD_NOT_PROOF_OF_POWER_CYCLE', label=label,
                tool_revision='spectrum_boot_identity_r3_1', recorder_sha256=digest(Path(__file__)),
                utc=datetime.now(timezone.utc).isoformat(),
                boot_id=(proc_root / 'sys/kernel/random/boot_id').read_text().strip(),
                uptime_s=float((proc_root / 'uptime').read_text().split()[0]),
                python=sys.version, kernel=platform.release(), package=str(base),
                build_revision=manifest['build_revision'], sha256=hashes,
                package_files_verified=len(manifest['files_sha256']),
                actual_power_cycle_requires_operator_confirmation=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, default=Path('/home/xilinx/jupyter_notebooks/spectrum_software_v1_r3'))
    parser.add_argument('--label', choices=('boot01', 'boot02', 'boot03'), required=True)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    if platform.system() != 'Linux':
        parser.error('Run on the actual Linux board after a physical power cycle')
    result = record(args.base, args.label)
    output = args.out or Path.cwd() / ('spectrum_r3_' + args.label + '_' + uuid.uuid4().hex[:10] + '.json')
    with output.open('x', encoding='utf-8') as log:
        json.dump(result, log, ensure_ascii=False, indent=2)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print('Return:', output)


if __name__ == '__main__':
    main()
