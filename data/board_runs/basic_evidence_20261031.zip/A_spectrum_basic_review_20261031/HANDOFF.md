# 项目交接说明：PYNQ-Z2 实时频谱分析仪

原始交接核对时间：2026-10-22 21:24；最新增量更新：2026-10-31（Asia/Shanghai，北京时间）。

## 当前交接快照（继续工作先读本节）

**新对话入口：先读[基础功能复核与交付清单](pynq-z2-spectrum-analyzer/docs/a_spectrum_basic_review_20261031.md)及[r3三次冷启动核验](pynq-z2-spectrum-analyzer/docs/a_spectrum_r3_coldboot_validation_20261031.md)。基础功能及本轮计划内板测已完成：r2长测/显示/恢复、PC与ARM基准、r3短复验和三次实际冷启动均已核验。不再要求重复冷启动、旧长测或ARM；当前转入CMA问题与最终材料收尾。**

**当前状态：`BASIC_FUNCTIONAL_REGRESSION_VERIFIED_CMA_REVIEW_PENDING`。** 用户回传三份boot JSON及三个原生ZIP，且明确回复“三轮都实际断电后重新上电”。boot01/02/03的boot_id各不同，r3 manifest、35文件验证、记录器SHA256及硬件身份一致；三个服务实例独立，每轮100帧，分别20.007711884、20.016082050、20.012633102秒，在线单音及安全停止均通过。新归档`build/spectrum_r3_coldboot_validation_20261031_01/`保留六份原件与操作人确认；共300帧、6份原始留样、7张界面图。冷启动记录与会话按用户提交顺序配对，核对版本/环境；未声称ZIP内含boot_id或具独立电气断电测量。

基础功能复核通过不等于全部项目验收：CMA分配来源仍开放，r3仅短测/冷启动，不冒称已做r3版30分钟；真实LIVE录像和最终DOCX/PDF仍待更新，`board_accepted=false`保持。基础复核包`release/spectrum_basic_review_20261031/A_spectrum_basic_review_20261031.zip`汇集当前r3安装包、原始证据、审计结果和已知问题。当前不追加板测，先用现有证据整理CMA与材料。

此前r3短复验原生会话：`spectrum_session_6dd45c6249f6_export01.zip`，SHA256 `0465E96493BC1F9A9055620FABE767971B3D9D2B9090EEF36F34B2CE2255E5A1`，可信审计目录`build/spectrum_r3_validation_20261031_01/`。4次321帧、8份原始留样、8张图，4次功能运行及安全停止通过；两次tone1k分别20.019106641秒/100帧、20.016677435秒/100帧，序号121→221→321连续，r3/冻结硬件身份和原生导出CRC/哈希通过。另两次observe分别20秒和手动停止4.18秒，未冒称在线单音断言。完整600秒/双音/静音矩阵审计字段保持false，按本轮短测范围登记通过，不重新定义完整矩阵。

此前r2救援包、资源日志及终端输出仍有效：救援CRC、502份负载SHA256和原始run manifest通过；本地重建输入区别于原生导出，没有改原manifest或执行收件代码。归档`build/spectrum_board_validation_20261031_01/`，原件救援ZIP SHA256 `B957B4B9DDEEC281E116E3BD77A90A77D8B4CBA148D460470802A55ED70678AC`。以下r2长测不冒充r3长测。

- 同r2实例14次18537帧，11次功能运行、3次失败诊断均保留；90份留样/23张界面图，14次安全停止，跨run序号0～18537连续。旧export02的129份核心记录/原始样本字节一致。
- 正式长测`spectrum_a148e0dd0a6f`：1820.013160629秒/9100帧、连续前台1819.799418538秒、9100条可见回执、0隐藏，在线单音及安全停止通过。原600秒显示和本轮1800秒显示要求均关闭，不重跑。
- 随后同服务/Overlay恢复`spectrum_803d7babfd26`：20.031739564秒/100帧，自动完成、单音及安全停止通过，序号18437→18537。另一次620秒连续显示也通过。505秒失败run最后一帧单音条件不满足，物理原因未实证，原件和错误保留。
- 长测RSS73453568字节恒定、FD17→15，CmaFree净减12201984字节（11.63671875 MiB）。独立观察器65点/1900.033秒通过，PSS首尾相同但非全程恒定；观察器与长测完整时间重叠未证实，不强行对齐。CMA来源仍待查，`board_accepted=false`保持。
- ARM的`cpu_fft_arm_20261031.csv`及JSON现已收到核验：12类、20批×500次，240批原始计时、CSV/JSON全部字段、冻结输入哈希及参考标记一致；均值351.8725028～372.8343343 µs。原件及receipt在`build/cpu_fft_arm_validation_20261031_01/`，无需再执行ARM。该记录是CPU微基准，不是PL延迟或加速比。
- 当前r3短复验和三次冷启动均通过，不再切换软件或重做已通过项目。最后一次已核验会话为`instrument_0fa493c5aa53`，fs47998.56226619202 Hz，序号0→100安全停止。各次启动fs独立测量，不要求跨boot序号连续。
- 独立工具`release/spectrum_r3_boot_tools_20261031/record_spectrum_boot_r3.py`保持原件不改，7项HOST检查和本轮三份实际boot输出均核对通过；主机检查和物理断电说明分开归档。六份冷启动文件已收齐，不再要求用户上传脚本或回传同批数据。
- 真实录像、CMA、最终报告/验收继续待补，`board_accepted=false`保持。旧DOCX/PDF仍为当日候选稿，由新增Markdown报告补充证据。新r3证据包`release/spectrum_validation_20261031/A_spectrum_r3_validation_20261031.zip`；原软件/旧包不改。
- 本地证据包：`release/spectrum_validation_20261031/A_spectrum_rescue_validation_20261031.zip`。不需要再为本轮补下载重复原生ZIP；不删除板端文件、不改外层目录、不重新采集已通过矩阵。用户继续负责硬件操作，Codex负责核验及原B软件/材料。

## 2026-10-30取回前快照（历史，以上节为准）

**新对话入口：先读[本轮接续与文件回传清单](pynq-z2-spectrum-analyzer/docs/新对话接续_20261030.md)。用户当前要找本轮结果交回核验；下一步是取回文件，不是再跑30分钟。最新Jupyter根目录截图已显示救援脚本、r2目录、资源工具目录和CPU工具目录，实际生成结果仍需进入子目录/读脚本输出核对。**

**最新操作反馈：用户已确认导出报Worker command still pending。** r2默认15秒命令等待已超时，后台任务未被取消，尚待目录/CRC确认ZIP是否最终完成。先按[导出恢复步骤](pynq-z2-spectrum-analyzer/docs/spectrum_export_recovery_20261030.md)检查现成ZIP或保全原始数据，不重跑长测、不停止服务。已另备[r3导出修复候选](pynq-z2-spectrum-analyzer/docs/software_export_hotfix_r3_20261030.md)：HTTP两种导出等待300秒，其他控制仍15秒；34项HOST及干净包7类REPLAY/导出/审计通过，27项M4/RTL/契约及硬件不变。实际板端仍r2，先收到并核验当前数据再安排切换。

**状态：`BOARD_UI_LONG_RUN_VALIDATED_DISPLAY_REVIEW_PENDING`。** 当前依据为用户export02和本节最新审计。620秒在线单音采集、双音两窗、静音及停止恢复通过；连续前台600秒及CMA归因尚未闭环。`board_accepted=false`保留。历史“待首次上板”“需再跑双音/静音”不作为当前待办。

### 1 工作区与分工

- 工作区`D:\AMD_compitition`，主工程`D:\AMD_compitition\pynq-z2-spectrum-analyzer`。外层目录未改名，避免破坏Vivado绝对路径。
- 用户负责接线、播放、实际板测、关机供电和返回文件；Codex负责软件、核验、指标及材料。用户本轮明确授权连同此前B的任务直接完成，不再以等待B为软件推进前置条件；不虚构B本人签收。
- [原B后续计划](pynq-z2-spectrum-analyzer/docs/B后续操作步骤_20261029至1101.md)保留。当前实际完成情况见[B任务对照](pynq-z2-spectrum-analyzer/docs/B任务完成对照_20261030.md)。

### 2 当前有效进度

| 工作块 | 当前结论 |
| --- | --- |
| 冻结FFT 数值与硬件 | FFT v1.0，12主例+2恢复例、真实RTL对官方模型0整数差异；bit/hwh及27个M4保护项保持；外部I/O时序限制保留 |
| 原驱动长跑 | 600秒3000帧、停止恢复、双音静音、完整Notebook有效；空闲120秒JSONL已补齐；CMA来源仍待查 |
| 基础软件 | r2频谱/瀑布、LIVE/REPLAY、窗/峰值、有限留样、导出与独立审计已完成；既有28项主机检查保持有效 |
| r2此次实板 | 9次3542帧、7次功能运行；28原始留样/11界面图；9次安全停止；620.015秒3100帧在线单音、双音两窗和静音通过 |
| 显示缺项 | 长测约437秒两条隐藏回执；最长连续可见436.534秒，未达600秒；采集结果仍有效 |
| 指标与B材料 | 实测表/3图/12类PC基准/8页DOCX PDF报告/README 环境 问题 索引/演示分镜与字幕/本地候选包已备 |
| 发布进展与未核验 | 用户反馈约30分钟抽查正常，本轮原件待取回；实际时长/前台/20秒恢复及ARM、三次冷启动、CMA、真实录像与最终验收仍待证据 |

固定xc7z020clg400-1、左声道1024点；LINE IN→codec/I2S→PL窗/FFT→64位复数/S2MM→PS幅值/峰值→浏览器。PS不二次FFT。自然序、低32real/高32imag各signed16符号扩展，S=11恢复后分别除16；单边中间点乘2，矩形窗和1024、Hann511.50006103515625。协议0x46465401、8192字节/帧，快照允许帧间间隙。

### 3 最新实测与归档

- 原件`spectrum_session_a79f9a7236b2_export02.zip` SHA256 `3E7FFF49310213C024F073566E5420B5F69727BD9E9C225698B90D7272EBD62E`；同实例`instrument_a79f9a7236b2`，BOARD_LIVE/r2，可信审计为SESSION_DATA_VERIFIED_REQUIREMENTS_PENDING。
- 长测`spectrum_569e5f254203` Hann/tone1k：620.01506344秒/3100帧/4.999878524 Hz，在线检查逐帧通过，DURATION_COMPLETE，安全停止。fs47998.569313695836 Hz；主峰bin21/984.345659754 Hz，中位-12.93601024 dBFS。
- 双音矩形`spectrum_f5953d8dcaa0`、Hann`spectrum_38749b56cab6`、静音`spectrum_15131a729d8b`各40帧通过。两段早期1帧单音失败保留，均安全停止，未单独实证物理原因。
- 长测浏览器3096回执/4.993195485 Hz，最长连续可见436.534秒。RSS72978432字节恒定，FD17→15，全局CMA70852608→66707456字节，净减3.953125 MiB且两次回升，不能据此宣布泄漏或无泄漏。
- 板端Python3.10.4、NumPy1.21.5、PYNQ3.1.1、Linux6.6.10-xilinx-v2024.1。PC完整12类同输入FFT每类20×500调用，均值8.98501～9.27658 µs；与capture调用不是同计时范围，不报告加速比。
- [详细核验](pynq-z2-spectrum-analyzer/docs/a_spectrum_export02_20261030.md)，审计`build/spectrum_board_validation_20261030_02/audit.json`，新receipt为同目录`report_data/validation_receipt.json`。

| 用途 | 当前文件 |
| --- | --- |
| 现有板端软件 保持r2 | [spectrum_software_v1_r2_board.zip](pynq-z2-spectrum-analyzer/release/spectrum_software_v1_r2/spectrum_software_v1_r2_board.zip) |
| 最新结果及B材料包 | [A_B_software_review_20261030.zip](pynq-z2-spectrum-analyzer/release/spectrum_validation_20261030/A_B_software_review_20261030.zip) |
| 当前下一步 取回本轮文件 | [新对话接续与回传清单](pynq-z2-spectrum-analyzer/docs/新对话接续_20261030.md)；[导出恢复](pynq-z2-spectrum-analyzer/docs/spectrum_export_recovery_20261030.md) |
| 已执行轮次的原操作说明 | [下一轮板测](pynq-z2-spectrum-analyzer/docs/下一轮板测_20261030.md)，不据本页重跑 |
| r3后续候选 尚未部署 | [r3修复说明](pynq-z2-spectrum-analyzer/docs/software_export_hotfix_r3_20261030.md)；先保全r2数据 |
| B已完成及剩余 | [B任务完成对照](pynq-z2-spectrum-analyzer/docs/B任务完成对照_20261030.md) |
| 机器状态 | [current_status.json](pynq-z2-spectrum-analyzer/build/fft_delivery_20261024_v1/current_status.json) |

原r2板端ZIP SHA256 `D6F01E440CB184AD08E052A6A9C0789B7EA7CCFF0FA6EEA34A087E2DFDD51E1A`，manifest `E1A84240287AF06490C8B4144E94E5A8D21A205913CEDB8F9FA22FEC08D6CCBA`。原软件包不变，新增独立只读观察/boot工具不覆盖r2。

用户最新口头反馈：不定时抽查约30分钟内频谱显示正常；尚未收到这轮原始ZIP，正式30分钟、连续前台及恢复验收保持待核验，当前不要求重复长测。

### 4 下一步实际动作

1. 保留现有r2服务和原始数据；确认采集已停止，不继续点网页导出，不先升级、重启或清理。当前只拿回已有结果，不再安排一次30分钟。
2. 用户截图已显示根目录有`spectrum_export_rescue.py`。第二终端运行`cd /home/xilinx/jupyter_notebooks`及`python3 spectrum_export_rescue.py`，读出完整ZIP路径和CRC。
3. 有包含本轮长测/恢复且CRC通过的`spectrum_session_...zip`，直接通过Jupyter下载；默认位置为`spectrum_software_v1_r2/spectrum_results/`。没有完整ZIP时运行`python3 spectrum_export_rescue.py --backup`，下载根目录新生成的`spectrum_rescue_...zip`。救援备份不是原生会话格式，收件后先核验救援manifest再恢复审计。
4. 一并返回观察器`spectrum_resources_*.jsonl`，通常在`spectrum_validation_board_tools_20261030/`，以终端Output为准。若已执行ARM基准，返回`b_cpu_benchmark_20261029_1101/`中的`cpu_fft_arm_20261030.csv`和同名JSON；未执行先不阻塞现有结果取回。三次冷启动结果仅在实际做过时回传，不推定已完成。
5. 新对话Codex新建审计目录，核对实际≥1800秒、连续前台、逐帧质量/状态、停止和20秒恢复、CMA与ARM结果，再决定实际剩余项和r3安全切换。不默认重跑双音/静音或30分钟。

截图中的旧修改时间不能用于判断本轮日期。文件清单、具体路径及可复制命令见[接续操作单](pynq-z2-spectrum-analyzer/docs/新对话接续_20261030.md)。不需要用户回传安装包、音频或整个Jupyter目录；已收到的PNG不要求重复发送。用户负责实际板卡操作，Codex继续一并承担原B软件和材料工作。

### 5 B工作与边界

- B-W06本轮矩阵、B-W08等价阶段材料、B-W09基线、B-W10已有证据指标整理、B-W12候选版本说明、B-W14候选报告、B-W16本地内审包已完成。
- B-W07已完成620秒采集/性能资源统计，前台600秒和CMA未关闭；B-W11完成14例参考引用与PC基准，ARM及同口径硬件性能待补；B-W13工具/音频/操作准备完成、实际发布回归待做；B-W15完成分镜/字幕/离线复现步骤，真实录屏和独立依赖环境复现仍未完成。
- B6-01有指标和报告候选稿；B6-02有固定r2、README/环境/问题表与本地候选包；B6-03有脚本/字幕/素材结构，未虚构最终录像、对外提交或B签收。
- CMA、物理电压、THD/SNR、纯PL/同步端到端延迟、完整外部I/O时序独立跟踪。DDS/RC及独立PS GUI补建为后续条件项。旧ZIP、RTL、原始失败记录不改；不放宽断言/修改manifest收尾。
- 板端清理仍待完整目录及备份核对，未删除文件；外层目录未改名。没有新权限/确认流程或外部发信。

## 历史交接与阶段记录（以下保留生成时状态）

以下段落用于追溯；当前部署和下一步以上述2026-10-30快照与最新实测核验为准。

**r2实板短测通过（2026-10-30）：BOARD_UI_SMOKE_VALIDATED_LONG_RUN_PENDING。** 已核验用户回传 `spectrum_session_a79f9a7236b2_export01.zip`（SHA256 DA0118BB4BD77DC5CE72273DB54068C5412A194897D3682CFEBC466BB73997EA）：BOARD_LIVE/r2/Hann97帧+矩形54帧，硬件序号1～151连续，同Overlay两次STOP_REQUESTED/安全停止；4份原始留样、3张界面图及版本/哈希/复数重建通过。fs47998.5693Hz、主峰984.3457Hz；板端Python3.10.4/NumPy1.21.5/PYNQ3.1.1，首次PYNQ线程初始化阻断已在该环境消除。两次实际场景为observe，4份留样补做1kHz检查通过、全部151条主峰也在一bin内；不冒充在线tone1k断言。Hann开头约6秒隐藏页面，后续长测必须前台。当前无需新包/重跑已完成短测，保持同一服务继续Hann/tone1k620秒/5Hz，双音矩形/Hann各8秒、静音8秒，再导出新编号整会话ZIP。详见[r2短测核验与下一步](pynq-z2-spectrum-analyzer/docs/a_spectrum_board_validation_20261030.md)，审计和指标位于主工程 `build/spectrum_board_validation_20261030_01/`；证据包 `release/spectrum_board_validation_r2_v1/`。新UI十分钟/完整矩阵、发布冷启动/30分钟与CMA归因仍待完成，旧软件/ZIP不改。以下“r2待首次实板复验”由本段更新。

**最新软件修复（2026-10-29）：HOST_HOTFIX_VALIDATED_BOARD_RETEST_PENDING。** 用户首次运行新界面时回报8091已有监听进程；已运行的v1服务在PYNQ初始化时报硬件线程无current event loop，尚无有效采集。已发布构建 `spectrum_software_1_r2`：在硬件所有者线程创建/设置并安全关闭asyncio loop，补28项主机回归；端口冲突给出明确提示，提供按端口/PID识别并仅发SIGINT的 `spectrum_service.py`。r2完整解压后导入、真实PL回放、导出及新审计入口通过，旧v1与r2的manifest仅按各自可信receipt接受。硬件/数值/前端及历史ZIP未改，27个M4保护项核验通过。当前只需用户上传 `release/spectrum_software_v1_r2/spectrum_software_v1_r2_board.zip`，解压到新目录，先运行stop工具停旧服务，看到STOPPED/PORT_FREE再启动并验证1kHz至少10帧/停止恢复；详见[r2修复与重启步骤](pynq-z2-spectrum-analyzer/docs/software_hotfix_r2_20261029.md)。完整r2包给后续B审计使用。此次HOST验证不代替板上复验，CMA仍跟踪，以下v1首次部署步骤由本段覆盖。

**协作与后续计划更新（2026-10-29）：用户确认B可继续工作。** 已按“B-W08验收完成后”为计划起点，编制到本周日2026-11-01的[B详细后续操作单](pynq-z2-spectrum-analyzer/docs/B后续操作步骤_20261029至1101.md)，覆盖B-W09～B-W16：接续/缺项核对、指标与资源统计、同输入CPU基准、候选冻结、三次冷启动/30分钟、报告、视频/复现、周日候选包。B负责分析、测试组织和材料；用户继续负责硬件实际操作，Codex支持版本修复与核验。配套转发包在 `release/b_followup_20261029_1101/B_followup_20261029_1101.zip`（主工程内），含既有软件/板测原件、11份模板、3个辅助工具和板上CPU工具包。7个PowerShell块语法、工具主机小样本、ZIP清单/CRC核验通过；这些是准备材料，不表示B-W08已实际完成、已发送给B或已执行新的上板/冷启动/长跑。原软件包和实际验收状态不变，以下B退出/由Codex独立接管的描述属于恢复协作前记录。

**软件接管交付（2026-10-29）：HOST_VALIDATED_BOARD_UI_RUN_PENDING。B已退出，Codex负责全部软件，用户负责硬件调试/上板。** 基础频谱应用已完成：浏览器频谱/瀑布、LIVE/REPLAY、窗/幅值/峰值、停止恢复、有限留样、绘制/性能记录、整会话导出及独立审计。21项主机测试、14例冻结官方参考与既有RTL输出逐位复核、实际浏览器620秒REPLAY及完整候选包7类样本/8次运行验证通过。板端只上传 `release/spectrum_software_v1/spectrum_software_v1_board.zip`，按[当前上板步骤](pynq-z2-spectrum-analyzer/docs/software_delivery_20261029.md)启动，短测停止恢复→620秒前台显示→双音/静音→回传一个整会话ZIP。完整归档 `release/spectrum_software_v1/A_spectrum_software_v1.zip`；详见[软件接管记录](pynq-z2-spectrum-analyzer/docs/software_takeover_20261029.md)。新LIVE界面尚未板测，CMA归因继续独立跟踪；后续由Codex接实测修复并推进标定/DDS/RC软件。冻结硬件与历史ZIP保留；以下“等待B文件/签收”是责任调整前历史状态，不再作为当前推进前置条件。

**空闲JSONL补交核验（2026-10-29）：BOARD_IDLE_OBSERVATION_DATA_VERIFIED。** 原始 `cma_idle_b8ee4ce2489b.jsonl` 已收到并归档至主工程 `build/fft_cma_idle_validation_20261029_01/`；27条记录/25个观测点、120.013760104秒，时间及全部打印字段与终端一致。CmaTotal128MiB恒定，CmaFree净减少188KiB并有回升，MemAvailable约255MiB。采集期间CMA下降的分配来源仍未确定，`cma_review_pending=true`保持；空闲证据补交已完成，当前不追加重复板测。下一工作块是接B现有.py/.ipynb显示入口、依赖及启动说明；本地sw/未找到该入口。先用真实PL结果回放对接，再做实采显示联合验收。完整记录见[空闲JSONL核验](pynq-z2-spectrum-analyzer/docs/a_fft_cma_idle_validation_20261029.md)；新归档修订为 `release/fft_campaign_board_validation_v2/`，原v1不改，B签收/显示十分钟/最终性能仍待办。以下“仅待回传JSONL”等为补件前历史状态，以本段为当前口径。

**空闲观测反馈增量（2026-10-29）：两分钟观测已执行，当前仅待回传既有JSONL。** 用户终端显示25点/120秒/DURATION_COMPLETE；CmaFree净减少188KiB，期间有上升恢复，波动跨度228KiB，未呈持续单向下降。已按“用户贴出的终端输出”归档至主工程 `build/fft_cma_idle_feedback_20261029_01/`，原始 `cma_idle_b8ee4ce2489b.jsonl` 尚未收到，完整全局计数及观测间隔活动仍待核对。十分钟功能通过保持不变，CMA归因继续待查，不据此登记无泄漏或完整稳定性通过。下一步只需用户回传已生成JSONL，无需重复两分钟或十分钟；详见下列回传核验报告的新增章节。以下较早段落的“下一步运行空闲观测”是补充反馈前的快照。

**长期采集回传核验（2026-10-29）：BOARD_DRIVER_10MIN_VALIDATED_CMA_REVIEW_PENDING。** 用户回传 `campaign_results_7a72583f9b13_export01.zip`，主机已独立核验600.001秒/3000帧、同Overlay停止恢复、双音/静音、24份原始留样与完整7格Notebook。正式测试通过；4次早期测试音检查失败均安全停止，作为历史排障保留。RSS/FD/history稳定，但全局CmaFree由46.0039降至43.1875MiB（减少2.8164MiB），原因未定，不登记完整内存稳定性或整个项目验收通过。下一步用户在现有会话空闲时运行 `sw/pynq/observe_fft_cma_idle.py` 两分钟并回传JSONL，无需立即重复十分钟。报告及操作见[长期采集回传核验](pynq-z2-spectrum-analyzer/docs/a_fft_campaign_board_validation_20261029.md)，审计见主工程 `build/fft_campaign_board_validation_20261029_03/audit.json`。新证据包在 `release/fft_campaign_board_validation_v1/`；原契约/RTL/硬件/历史ZIP未改，B显示/签收及后续指标仍独立待办。以下10/27和更早的“待上板”段落保留为历史状态，以本段为当前口径。

**接续核对（2026-10-27）：下一步仍为用户执行新版采集软件板测。** 已实查长期测试ZIP的SHA256、CRC、全部35个文件及解压目录、板端Notebook源/7个必需代码格、Python3.6语法；同版FFT bit/hwh、冻结契约和27个M4保护文件均一致，包内真实原始帧的主机回放通过。复核既有22项主机测试日志通过，本次未重跑测试或新增板上实测。状态保持`HOST_VALIDATED_BOARD_RUN_PENDING`，无需重建硬件或重复已完成的基础14帧测试。当前操作单见[接续记录与上板步骤](pynq-z2-spectrum-analyzer/docs/a_project_resume_20261027.md)，核对证据见`build/project_resume_20261027_01/verification.json`（主工程内）。仅上传长期测试包的`board/`，按`FFT_stability.ipynb`完成约15～20分钟操作后回传导出ZIP；B界面、签收及最终性能验收仍独立待办。

**当前执行工作块（2026-10-24）：长期采集软件HOST_VALIDATED_BOARD_RUN_PENDING。** 基础14帧/完整Notebook验收结论保持不变。新增fft_campaign_1软件：FFTCapture轻量持久化/最近状态、阶段耗时、统一LIVE/REPLAY帧接口、双上限有界采集、停止/重启、有限留样、JSONL和RSS/CMA/FD统计、保存检查/完整与未完成导出。原驱动6项+流程9项+归档7项主机测试通过，虚拟600秒记录为HOST_REPLAY_TEST，不冒充板上长期测试；板端Python3.6语法及独立整包导入/回放通过。固定xc7z020clg400-1、RTL/FFT契约和原bit/hwh不变。候选包`release/fft_campaign_v1/A_fft_campaign_v1.zip`；只上传board/，PC_audio/留Windows播放，按FFT_stability.ipynb运行约15～20分钟并回传ZIP。当前下一步需要用户上板，这轮无需B前置代码；B显示界面10分钟等联合指标仍待其实际入口。详情见 [长期采集工作块](pynq-z2-spectrum-analyzer/docs/a_fft_campaign_20261024.md)。

**Notebook归档最新增量（2026-10-24）：BOARD_SMOKE_EVIDENCE_COMPLETE。** 用户补交`FFT_acceptance_executed_20261024.ipynb`（SHA256 679A1626EDB3F5629E7764107863A427D817FB254C4CD38D06CBF577E4719FAB），七个必需代码格执行1～7、三张图、14帧PASS及后续输出与原始数据一致，原先Notebook缺口已关闭。补全记录在`build/fft_board_notebook_completion_20261024_01/`。证据包更新为`release/fft_board_validation_v2/A_fft_board_validation_v2.zip`，v2仅为归档修订；原FFT契约/硬件v1.0及旧ZIP不改。B签收、双音/静音、10分钟显示、幅值/性能等后续事项仍待推进。以下旧段落的“Notebook待补”保留为补件前历史状态，不再作为当前待办。

协作同步增量（2026-10-24）：已对照本周B-W03～B-W08梳理依赖。A现有RTL/仿真/硬件/基础板测无待B文件的前置阻塞；联合显示需B现有.py/.ipynb入口与调用说明，B-W05需独立fft_compare.csv/脚本日志，B-W07需显示回归/性能/10分钟记录，B-W08需周包。A已提供冻结输入/模型，B复核接入，不再等B重新生成正式黄金向量。同步说明和可直接转发文字见 [A/B进度同步](pynq-z2-spectrum-analyzer/docs/a_b_sync_20261024.md)。新增结果/硬件/板测三包本地准备，尚未代用户发给B或登记B签收；板卡在A，B可先离线回放，入口交A上板代跑。

**板测最新增量（2026-10-24，以本段覆盖下文BOARD_PENDING历史状态）：SIM_VALIDATED / BOARD_SMOKE_VALIDATED。** 用户回传`fft_results_20250503_233204.zip`，14帧原始uint64数据/状态/复数保存值独立核验通过，硬件记录哈希与交付匹配。fs47998.38935Hz；1k/2k峰值984.34197/2015.55737Hz；10帧Hann峰值跨度0.030127dB；手动降低Windows/播放器音量后幅度比0.09075256（-20.84282dB）。已保存Notebook停在十帧步骤，后续原始数据齐全；需补保存当前已执行Notebook，采集无需重跑。2025文件名按旧板卡时钟标签保留，接收/核验日期2026-10-24。B签收、长期/幅值/性能指标及完整Notebook归档仍待补，不登记整个项目BOARD_ACCEPTED。详见 [板测核验记录](pynq-z2-spectrum-analyzer/docs/a_fft_board_validation_20261024.md)。以下“下一步上板”等段落保留为构建时快照，本次已完成的测试不重复执行。

**当前进度（2026-10-24本轮实施后，以此段覆盖下文历史“待实现”口径）：FFT已完成真实RTL仿真和独立硬件构建，状态SIM_VALIDATED / HW_BUILT_BOARD_PENDING。** 矩形四例、完整12组加2个ABORT恢复帧均为零整数差异；协议/控制/错误检测回归通过。复用M4采集/PS/DMA在`_fb01`综合实现并生成同版FFT bit/hwh，WNS0.585733ns/WHS0.019605ns；保留外部I/O约束及原板卡预设警告，未登记完整外部时序签核。27个M4保护文件和冻结v1.0包不变。当前结果详见 [A实施记录](pynq-z2-spectrum-analyzer/docs/a_fft_implementation_20261024.md)。

本地完整B-W05结果包：`release/fft_chain_sim_v1/A_fft_chain_results_v1.zip`，Codex未发送。上板候选包：`release/fft_delivery_v1/A_fft_delivery_v1.zip`，含同版bit/hwh、驱动、`FFT_acceptance.ipynb`、报告/日志和重建源。下一步由用户按Notebook在LINE IN输入1k/2kHz完成板测并反馈；B适配/签收、BOARD_ACCEPTED和性能验收仍待证据。以下段落保留此前阶段记录，不据历史文字重复实施已完成步骤。

最新进度：M4 两份本地 Python 模块已同步 CFFI 修复并通过核验；ROSS 在独立短路径工程中确认 Vivado 2026.1、xc7z020clg400-1、FFT IP 9.1 创建/模型生成及现有 counter 自检通过。原 M4 bit/hwh 哈希不变；板上模块同步、正式导出与 B 签收仍待另行完成。详见 [本轮预检报告](pynq-z2-spectrum-analyzer/build/ross_preflight_20261023_01/ross_preflight.md)。

后续用户已确认将 `M4_for_B.zip` 发给B；发包记为已交付，包内版本/本地归档与B最小复现签收仍需按记录核实。第二步现已由A独立完成：`docs/fft_contract.md` **v1.0 / A_TECHNICAL_FROZEN**。17项静态配置、BD验证/模型生成/干净重建及窗/布局18项检查已有证据；同安装版官方xfft9.1 C模型已运行，生成12组参考、25项检查通过，零整数差异验收规则已冻结。见 `docs/a_fft_freeze_20261024.md`、`docs/a_fft_contract_runbook.md` 及本地包 `release/fft_contract_v1/A_fft_contract_v1.zip`。用户授权A定稿，B适配/签收单独跟踪，不是A进入第三步的前置条件。下一步是实际PL窗/FFT RTL自检；运行配置握手、RTL数值/协议回归、系统集成、新bit/hwh和板上验收均未完成。本次保护的27个M4文件与原bit/hwh保持一致。

## 1. 信息来源与状态口径

协作分工（用户明确指定）：Codex负责A侧的技术方案、参数选择、契约文档、RTL/Python/测试代码、本地仿真、构建与交付包；用户负责实际接线、上板调试和反馈日志/波形/现象。普通技术选项由Codex依据项目范围和验证结果决定，不要求用户自行配置FFT或填写技术契约。B负责其PS/模型/显示适配，是否确认单独记录，不虚构签收或联合验收。

上板配合更新（2026-10-24，用户明确指定）：板卡目前在用户身边。后续任务一旦需要实际接线、加载Overlay或板上运行，直接通知用户，提供当前版本的可运行产物、逐步操作、预期结果及需要返回的日志/波形/数据，无需再询问板卡是否可用。具体上板结果仍以用户反馈的实际证据登记。

交付增量（2026-10-24，用户报告）：用户已了解A操作单，并已将冻结记录及 `release/fft_contract_v1/A_fft_contract_v1.zip` 发给B。登记为“已发送，B确认/适配结果待反馈”；本地ZIP哈希已复核保持不变，不能据此推定B端文件已核验。发送状态另存 `release/fft_contract_v1/delivery_status_20261024.json`，保留原打包receipt的生成时快照及冻结ZIP不变。下一步和B-W03/B-W04功能边界见 `docs/a_next_fft_and_bw03_bw04_20261024.md`。

矩形路径准备增量（2026-10-24）：已创建sim/tb_fft_rect.sv、hw/scripts/sim_fft_rect.tcl、sw/reference/verify_fft_rect.py和独立工程 `D:/AMD_compitition/_fr01/fft_rect.xpr`。固定器件/FFT配置17项回读一致；实际xvlog/xvhdl和xelab通过，生成tb_fft_rect_behav快照，校验器6项合成自检通过。结果在 `build/fft_rect_sim_20261024_01/`，细节见 `docs/a_fft_rect_preparation_20261024.md`。四组功能仿真及0x0557实际握手仍未运行；下一步从该工程执行run和真实结果verify，不重新创建或覆盖已准备目录。

- 工作区根目录：`D:\AMD_compitition`；主工程：`pynq-z2-spectrum-analyzer/`。下文工程内相对路径均以主工程为起点。
- 已读取同项目聊天 **“fpga”**（ID：`01a14994-30b3-7bd3-9295-3c9eb0ebb059`）最近两页，共20轮记录，覆盖 M4 修复、构建、板上验收、交付讨论和下一阶段计划。
- 本次同时核对本地源码、构建产物、仿真日志、最终 timing/clocks/CDC 报告及工作区外的 B 阶段任务文档。
- 原始10/22核对中，“本地已核对”指读取文件得到的证据，“聊天已记录”指此前用户输出或截图；当时未重跑工具/板卡。10/23～10/24增量工作实际运行了独立 Vivado/XSim 预检和本地 CFFI 模拟检查，未新增板上实测。
- 文中“计划/待确认”均不算完成。旧记录里“DMA仍失败、采样率约27.7kHz”已被后续板上结果更新，不能继续作为当前阻塞点。

## 2. 项目目标

在 PYNQ-Z2（Zynq-7000 / XC7Z020）上实现实时频谱分析仪与频率特性测量系统：PL 完成音频采集、分帧、加窗、1024点 FFT，以及后续幅值/峰值相关处理；PS/ARM 负责控制、结果解析、交互显示和测试记录。扩展方向是 DDS 扫频激励及幅频/相频（波特图）实测。

聊天中的分工：用户为 **A，负责 PL/FPGA**；**B 负责 PS/Python、显示、黄金参考、对拍和材料**。当前应优先完成基础频谱闭环，再推进扫频扩展。

## 3. 技术方案

### 当前已实现的 M4 采集链

`电脑模拟音频输出 → 板子 LINE IN → ADAU1761 ADC → I2S → PL 分帧 → AXI DMA S2MM → SmartConnect → PS DDR → PYNQ/Python`

- 工具：Vivado 2026.1；本地路径 `D:\AMDDesignTools\2026.1\Vivado`；器件 `xc7z020clg400-1`。
- PS FCLK_CLK0 为100MHz；PL 分频输出10MHz codec MCLK，管脚 U5。ADAU1761 的 I²C 七位地址为 `0x3B`；PLL 六字节配置从 `0x4002` 开始，目标48kHz，并实测 fs。
- DMA 为简单模式、仅 S2MM；软件先中止/清理旧状态、武装 DMA，再触发一次采集。固定1024拍，每拍64位，总8192字节；`TKEEP=0xFF`，第1024拍带 `TLAST`。
- 每拍高32位为左声道、低32位为右声道，各是24位有符号样本扩展到32位。Python 音频数组为 `(2, 1024)`、`int32`，归一化除以 `2**23`。
- 这是软件触发的时域快照，包间有间隙。重复采集通过不代表跨包连续音频流；左右声道不能当作 FFT 实部/虚部。
- 显式计数器测试源输出精确的 `uint64` 0～1023；真实音频与自检模式分开验收。包内背压造成丢样时设置 overflow，验收应失败。

### 当前控制接口

地址最终以同版 `.hwh` 的 `ip_dict` 为准，预期如下：

| IP | 基地址 | 用途 |
| --- | --- | --- |
| `axi_lite_ctrl_0` | `0x40000000` | CTRL 控制 |
| `dbg_stat_0` | `0x40001000` | LRCLK/握手计数、采集状态、最近样本 |
| `axi_dma_0` | `0x40400000` | S2MM DMA |
| `axi_iic_0` | `0x41600000` | codec 配置 |

CTRL 偏移 `0x00`：bit0上升沿触发一包，bit1中止并清分帧状态，bit2选择计数器源（触发时锁存）。真实音频写 `0x1`，自检写 `0x5`。其他旧寄存器仍为占位，LENGTH 不能动态改变本版1024拍。

`dbg_stat_0 + 0x08` 的高4位应为协议标识 `0xA`，低位 bit0/1/2/3 分别为 busy/overflow/test/done。完整位定义见 `sw/pynq/README_M4.md`。本版 LED 用于诊断，不能沿用 M3 的寄存器点灯验收方法。

### 下一阶段方案（计划，尚未实现交付）

在已验证的采集基础上接入 PL 加窗和1024点 FFT，再通过 DMA 向 PS 交付频谱结果。A已冻结FFT契约v1.0及官方模型参考；B按该版适配解析、幅值与显示。当前 Notebook 的软件 FFT 仅用于输入诊断，不能作为 PL FFT 完成证据。

## 4. 关键文件与版本选择

| 路径（主工程内） | 作用与状态 |
| --- | --- |
| `README.md` | 总目标和目录说明；其中部分目录是规划，不能据此判定已实现 |
| `hw/rtl/axi_lite_ctrl.v`、`dbg_stat.v` | 控制寄存器与采集诊断 |
| `hw/rtl/i2s/i2s_capture_wrapper.v` | M4 触发分帧、测试源、AXIS 握手和溢出等逻辑 |
| `hw/rtl/i2s/i2s_capture.sv`、`i2s_serdes.sv`、`rising_edge.sv` | I2S 采集、串并转换及同步相关逻辑 |
| `hw/constraints/i2s_audio.xdc` | 音频管脚、异步输入例外、MCLK 生成时钟约束 |
| `hw/scripts/build_m4_delivery.tcl` | 当前 M4 构建入口；检查仿真记录，输出独立交付目录 |
| `hw/scripts/recover_m4_mclk.tcl` | 复用布线检查点修复 MCLK 约束，重新检查并导出产物 |
| `hw/scripts/sim_m4_delivery.tcl`、`sim_i2s.bat`、`sim_i2s_vec.bat` | 分帧、I2S 回环、锯齿向量仿真入口 |
| `sim/tb_m4_delivery.v`、`tb_i2s_serdes.sv`、`tb_i2s_serdes_vec.sv` | 对应测试平台；向量在 `sim/vectors/` |
| `sw/pynq/m4_delivery.py` | 当前采集软件入口；本地 CFFI 修复已同步，板上副本另行核对 |
| `sw/pynq/M4_acceptance.ipynb`、`README_M4.md` | 逐步验收与当前 M4 接口说明 |
| `build/m4_delivery_20261018/pynq/` | 本轮 bit/hwh、软件、Notebook、三份最终报告、构建信息，共11个文件；软件副本已同步 CFFI 修复，其他文件未变 |
| `build/m4_delivery_sim.log`、`m4_delivery_recover.log` | 分帧通过与 MCLK 恢复成功证据 |
| `build/sim_i2s/xsim.log`、`build/sim_i2s_vec/xsim.log` | I2S 两项仿真通过证据 |
| `docs/interface.md` | M1 v1.0 旧契约，含32位复数/4096字节等早期约定；**不适用于当前 M4 音频格式** |
| `docs/a_week1_2_runbook.md` | 前期操作手册；包含已过时的 xsim/授权等状态，按历史资料使用 |
| `release/m3/`、`release/m4/`、`build/m4/` | 历史产物；`release/m4/` 是10月4日版本，不能代替本轮验收版 |
| `backup_m4_20261018_161201/` | 本轮改造前的部分源码备份 |
| `sw/pynq/LICENSE.reed-foster.txt` | 派生 I2S/codec 代码的 MIT 声明，交付须保留 |

工作区根目录的 `refs/` 是参考资料，`Tutorial/` 是早期半加器练习工程。`refs/pynq-audio-master` 中存在 FFT 代码不代表主工程已接入 FFT。原始核对时尚无FFT契约/模型；现已补齐v1.0契约、系数与官方C模型参考，主工程FFT RTL/集成仍待实现。正式M4 ZIP及板上结果的本地归档仍待核对。本地根目录和主工程目录均无法识别为 Git 仓库，因此没有可供引用的提交号。

## 5. 已完成工作与当前进度

| 工作 | 当前状态 | 依据或边界 |
| --- | --- | --- |
| 计数器/LED 基础设计 | 已完成基础验证 | 本地 counter 仿真有 TEST_PASS，且有构建产物 |
| M3 AXI-Lite 读写 | 聊天已记录通过 | 本地有控制 RTL、验收脚本和 bit/hwh；本次未重测板卡 |
| I2S 回环和向量仿真 | 已通过 | 本次读取日志确认；向量仿真固定延迟2帧 |
| M4 分帧与 AXIS 控制改造 | 已实现并仿真通过 | 软件触发、TLAST、重复武装、中止、背压稳定和溢出检查 |
| M4 硬件构建与 MCLK 约束恢复 | 已完成 | 10月18日16:32恢复成功；本地有同版 bit/hwh 和报告 |
| M4 DMA、codec、采样率、重复采集 | 聊天已记录板上通过 | 具体输出见第6节 |
| 真实音频输入与软件 FFT 诊断 | 聊天已记录修正接线后通过 | 正弦、音量响应及约984.34Hz峰值；仅限采集链与诊断 |
| CFFI I²C 缓冲区补丁 | 两份本地模块已同步并核验 | 字节一致、匹配既有修正版；12项修复用例及2项旧版类型失败复现通过，均为本地模拟 |
| ROSS 运行预检 | 独立工程通过 | Vivado 2026.1/固定器件/FFT 9.1创建与模型生成/counter XSim通过；不代表主工程FFT算法完成 |
| B-6 假频谱显示、B-7 DMA框架、B-8 RC理论脚本 | 聊天记录用户此前确认完成 | 本次未在主工程核对到 B 的完整成果；不能推定真实 PL 频谱闭环已完成 |
| M4 正式ZIP与B签收 | 用户已确认发给B；本地归档/版本及B签收待核实 | 发包不等于最小复现/签收通过 |
| PL 加窗/FFT、黄金对拍、真实频谱显示 | 计划/未交付 | 当前主工程缺少实现与验收证据 |
| DDS 扫频、波特图实测 | 后续计划 | RC 理论验证不能代替实测链路 |

当前阶段：**M4 采集核心已有板上通过记录，本地软件同步及 ROSS 运行预检已完成；待核对板上模块与正式交接。下一主线是 FFT 契约、PL 加窗/FFT。整个频谱分析仪尚未完成。**

## 6. 已验证的结果

### 本次读取本地日志/报告确认

- `build/sim_counter/xsim.log`：`TEST_PASS: counter counts and drives LED as expected`。
- `build/sim_i2s/xsim.log`：I2S 回环每帧还原通过。
- `build/sim_i2s_vec/xsim.log`：锯齿向量逐样本通过，`lag 2`。
- `build/m4_delivery_sim.log`：`TEST_PASS: 1024-beat TLAST, stall stability, one-shot, re-arm, abort, overflow`。
- `build/m4_delivery_recover.log`：`MCLK_CLOCK_PASS: codec_mclk_10m period=100.000 ns`，以及 `DONE: M4 MCLK constraint recovery complete`。
- 最终 `build/m4_delivery_20261018/pynq/delivery_timing.rpt`：WNS **+3.021ns**、WHS **+0.044ns**、TNS/THS 为0；用户指定时序约束满足。`no_clock=0`，内部未约束端点为0；仍有 `no_input_delay=5`、`no_output_delay=7`，不能写成“所有外部时序已完整约束”。
- 同目录 `delivery_clocks.rpt`：PL100MHz，codec MCLK10MHz（生成时钟、10分频）。`delivery_cdc.rpt` 列出6项 CDC-3 Info、均带 ASYNC_REG，未列出严重 CDC 项；这不替代外部接口完整时序分析。

本次计算的硬件 SHA256（目录：`build/m4_delivery_20261018/pynq/`）：

```text
m4.bit  07A075244EB332556556C6D46D1A7B8523CBDFF8FE6A23527FA33ADDBE832EF8
m4.hwh  C9721187B8E6AEEC91AEBB1FDA57148BA4C18E395758AEF0EC392062AC177F2D
```

### 来自“fpga”聊天的板上实测记录

- 计数器：`counter PASS bytes=8192`，首尾 `[0 1 2 3]` / `[1020 1021 1022 1023]`，精确序列断言通过。
- codec：`Codec PLL and line-route readback passed. PLL=0271023c2103`。
- 实测 fs：**47998.71Hz**；1024点频率间隔 **46.873738767483346Hz/bin**，满足本次±1%验收门限。
- 音频数组：`shape=(2,1024)`、`dtype=int32`；同 Overlay 会话 `cap_01`～`cap_10` 均 PASS，每次8192字节，约0.026秒量级。这是调用耗时记录，不是完整端到端实时延迟指标。
- 早期1kHz诊断曾错误落在46.87Hz。排查发现电脑输出路由及板端 HP/MIC 接口不匹配，改为电脑耳机模拟输出接板子 **LINE IN** 后恢复。
- 最新截图在原聊天中被判定为清晰正弦，正常 RMS 约0.086、低音量约0.00216（约1/40），诊断峰值约 **984.34Hz**，符合1024点频率栅格下的1kHz测试预期。
- 板上原始 npy、验收图、会话日志和完整已执行 Notebook 尚未在本地工程归档；上述板上结果是历史记录，本次未独立重放。

## 7. 待解决问题

1. **本地 I²C 补丁已同步，板上模块待核对。** 项目 `sw/pynq/m4_delivery.py` 和 `build/m4_delivery_20261018/pynq/m4_delivery.py` 已改用 `iic._ffi.new('unsigned char[]', count)` 并校验地址写入/接收长度。两份模块字节一致，SHA256为 `02AC9912502B7ACD8E7C648526457800019CAFC69BF75AA1F98F8C8916BB7CCA`；本地模拟通过，原版本及补丁在预检目录留档。尚未据此推定板上副本已更新或重新验收。
2. **正式交付证据未闭合。** 确认第7节 `make_handoff()` 成功输出，取回 `M4_for_B.zip` 与有效会话证据，记录包哈希并让 B 最小复现、签收。询问如何下载不能视作已下载或已签收。
3. **文档版本有冲突。** `docs/interface.md` 和早期 runbook 是旧阶段口径；应补 M4 实际接口说明及版本记录，再单独冻结 FFT 契约，不能将8192字节双声道格式套用早期4096字节复数约定。
4. **核心算法尚缺交付。** PL 窗、FFT、定点缩放/溢出处理、黄金参考对拍和真实频谱显示均需继续实施；硬件FFT结果格式已按v1.0由A冻结，实际RTL输出待实现与验证。
5. **指标和材料尚不完整。** 长时间稳定性、幅值校正、频率/幅值误差、刷新率、延迟、资源统计和完整复现材料需在后续闭环后验收；外部 I/O 时序约束缺项也需结合接口复核。

修正版位置（本次已确认存在）：

`C:\Users\rainy\Documents\Codex\2026-10-17\andrej-karpathy-skills-plugin-andrej-karpathy\outputs\m4-delivery-20261018\sw\pynq\m4_delivery.py`

## 8. 下一步（计划，按依赖推进）

1. **A 收尾 M4 板上基线。** 本地源码和构建目录的软件副本同步已完成；下一步核对并同步板上实际模块。此补丁只改 Python，无需因它重建 bit/hwh。重新使用模块时重启 Notebook 内核，避免保留旧 import。
2. **A/B 完成正式交接。** 板上目录为 `/home/xilinx/jupyter_notebooks/checkpoint2/m4_delivery_20261018/`，Jupyter 地址 `http://192.168.2.99:9090/`。核对有效会话的计数器、fs、音量变化、10次采集和已知音诊断后导出正式包。包内应保留同版硬件、修正版软件、Notebook、许可证、三份报告、validation 数据及 `validation_summary.json`。将 ZIP 和结果归档至本地 `release/` 的明确版本目录，B 签收后再更新状态。
3. **A侧FFT契约已冻结。** v1.0固定1024点、左声道、矩形/对称Hann、Q1.15、总缩放11、自然序、64位复数/8192字节；官方C模型参考与零整数差异规则已具备。B按版本适配，确认状态独立记录。
4. **B 推进独立软件工作。** 复用 B-6/B-7/B-8，完成黄金输入/浮点参考、真实 M4 数据重放和显示、对拍工具。软件 FFT 基线应标明来源，不能登记为硬件 FFT 成果。
5. **A 实现 PL 加窗/FFT。** 先用确定性向量仿真并与 B 对拍，再接入真实采集、生成新版同名 bit/hwh，交 B 联调；保留 M4 基线作为排障入口。
6. **联合验收与材料。** 真实单音/双音/静音测试，幅值和频轴校正，稳定性与基本性能记录，整理 README、报告和复现包；核心频谱闭环稳定后再推进 DDS/波特图。

既有 B 计划覆盖 **2026-10-18 至 10-25**，采用阶段交付而非固定每日任务，估算26小时（含3.5小时排错）。这是计划预算，不能据日期推定完成。当前实际文件已更名为：

`C:\Users\rainy\Documents\Codex\2026-10-17\andrej-karpathy-skills-plugin-andrej-karpathy\outputs\weekly-plan-20261017\B详细操作步骤.md`

接手时先读本文件，再核对当前 M4 README、实际代码版本和本轮报告；优先补齐版本同步与交接证据，随后继续 FFT 主线。Windows 操作沿用 PowerShell，板子内使用 Python/Jupyter 或 bash。
