# r2救援证据核验：30分钟显示与停止恢复通过

> 同日后续：ARM的CSV/JSON已收到并通过12类核验，均值351.87～372.83 µs。[ARM核验报告](a_spectrum_arm_validation_20261031.md)为最新增量；当前下一步已改为[r3两次20秒短复验](r3短复验_20261031.md)。本页以下的ARM待补描述保留为救援收件时快照，不能据此要求重复ARM。

收件与核验日期：2026-10-31，Asia/Shanghai。状态：**BOARD_UI_30MIN_AND_RECOVERY_VERIFIED_CMA_REVIEW_PENDING**。本报告是2026-10-30候选报告的新增实测附页；旧ZIP、旧审计和原报告不覆盖。板端仍为r2，未部署r3，未重跑板测。

## 本次结论

本轮原始文件已取回并通过完整性与可信审计。Hann/在线1 kHz单音长测实际1820.013160629秒、9100帧，连续前台1819.799418538秒，无隐藏回执，满足实际运行和连续前台均不少于1800秒的要求，也关闭原连续600秒显示缺项。之后同一服务、同Overlay的20.031739564秒/100帧恢复通过，序号衔接，均安全停止。**无需重复30分钟、双音、静音或已通过的基础测试。**

CMA分配来源仍未查明。ARM结果用户未找到，登记为未取得/待补，不推定已经执行。三次实际冷启动、真实LIVE录像及最终报告/验收仍待补；`board_accepted=false`保持。

## 原件与恢复来源

| 收件 | 字节数 | SHA256 |
| --- | ---: | --- |
| `spectrum_rescue_f4d98679c7cb.zip` | 6662946 | `B957B4B9DDEEC281E116E3BD77A90A77D8B4CBA148D460470802A55ED70678AC` |
| `spectrum_resources_c244f417c138.jsonl` | 65895 | `8A436C3BEE05821C2BF31DAD6FED0D0B8D4BC5686AE7C553C98B82A85D301599` |

原件及终端全文已复制到`build/spectrum_board_validation_20261031_01/originals/`，拷贝前后哈希一致。ZIP共503项、展开54392615字节；CRC、路径边界、无重复/符号链接、救援manifest覆盖及502份有效负载SHA256全部通过。收到的文本仅作为证据读取，没有执行其中代码或命令。

救援包是原始证据备份，**不是板端原生整会话ZIP**。本次保留全部原始文件、原始run导出manifest及driver_metadata，对每个run选用覆盖全部当前负载且哈希完全一致的原始manifest，仅为调用现有可信审计器在本地重建审计输入。原始run manifest字节不修改；本地生成的会话manifest和ZIP名在`reconstruction_provenance.json`中明确标记。`trusted_audit/audit.json`中的archive哈希指本地重建输入，用户原件哈希以本页及`input_receipt.json`为准。

终端另报告原生整会话export03～10的CRC均PASS，说明板端后台导出后来完成；这些原生ZIP未作为本次主机收件独立核验，不把终端声明等同于主机验签。本次救援数据已足够完成长测核验，无需为此再次下载这些重复ZIP。

## 功能、显示与失败记录

同实例`instrument_a79f9a7236b2`，软件`spectrum_software_1_r2`及35文件manifest身份通过；冻结bit/hwh与可信硬件receipt一致。共14次运行、18537帧、90份原始留样、23张界面图；11次功能运行通过，3次失败诊断保留，14次均安全停止。所有run之间硬件序号连续，从0至18537。与旧原生export02比较，129份旧运行核心记录/原始样本文件字节不变。

| 项目 | 本次有效证据 |
| --- | --- |
| 30分钟长测 | `spectrum_a148e0dd0a6f`，Hann/tone1k，1820.013160629秒，9100帧，DURATION_COMPLETE |
| 实际快照率 | 4.999963845 Hz；9100帧状态、序号及记录的单音断言通过；32份有限原始留样独立复算通过 |
| 前台显示 | 9100回执，全为visible=true，最长连续1819.799418538秒，最大回执间隔0.350763039秒 |
| 浏览器性能 | 5.000001598 Hz；canvas调用均值1.121703297 ms，P95约1.2 ms，最大8.5 ms；不是同步端到端延迟 |
| 20秒恢复 | `spectrum_803d7babfd26`，20.031739564秒/100帧，DURATION_COMPLETE，单音检查及安全停止通过 |
| 同服务恢复 | 长测序号9337→18437；恢复18437→18537；source_info除每次初始寄存器外一致 |
| 幅值观察 | 长测主峰984.345659754 Hz；dBFS中位-12.938606581，跨度0.029963956 dB；未做电压标定 |
| 额外连续显示 | `spectrum_b587e7a06a99`：620.011504572秒/3100帧，连续前台619.808625525秒 |
| 既有矩阵 | 同Overlay停止恢复、双音矩形/Hann、模拟静音仍通过，旧证据保持 |

新失败诊断`spectrum_1c512803838a`原设置1820秒，在505.076787525秒/2526帧结束。最后一帧1kHz候选幅值为0，单音断言失败；该帧PL/DMA/I2S及序号检查通过，随后安全停止，具体输入物理原因没有独立证据。失败原件、错误栈和末帧留样均保留，未通过删失败、放宽断言或修改manifest收尾。旧两次1帧诊断失败同样保留。随后完整1820秒通过是另一独立运行。

## 资源观察与边界

长测62个服务资源点中RSS恒定73453568字节（70.05078125 MiB）；FD 17→15，范围15～18。全局CmaFree44982272→32780288字节，即42.8984375→31.26171875 MiB，净减12201984字节（11.63671875 MiB），期间一次回升。

独立观察器共67行，其中65个sample、start和finish各1行，1900.032634843秒，DURATION_COMPLETE，无error行，process_start_ticks恒定。CmaTotal恒定128 MiB；CmaFree净减13352960字节（12.734375 MiB），Cached净增24891392字节，MemAvailable首尾增加774144字节。VmRSS/RssAnon首尾与整个采样范围均不变；PSS首尾均65310720字节，但期间范围48353280～65310720字节，不能表述为PSS全程恒定。FD范围14～17，首尾14→17。

观察器和服务run使用不同的相对时间原点，原件没有可证实的共同绝对起点；不能因为观察器1900秒就认定其完整覆盖该1820秒run。服务自身62点覆盖长测，独立观察器作为额外证据分开统计。板端UTC仍显示2025年，不据此更改收件日期或判断文件新旧。

这些证据支持“当前记录中服务RSS未增长，CMA全局计数下降”；没有分配调用来源，不能宣布CMA无泄漏、已证明泄漏或已定位到缓存。`cma_review_pending=true`继续保留。

![本轮长测及独立资源观察](../build/spectrum_board_validation_20261031_01/verified_long_run_and_resources.png)

## 救援收件时的下一步：ARM基准（现已完成）

无需先开启频谱服务、重新采集或升级。确认当前没有采集在进行，在板端Jupyter终端执行：

```bash
cd /home/xilinx/jupyter_notebooks/b_cpu_benchmark_20261029_1101
python3 measure_cpu_fft.py --host-root . --platform BOARD_PS --out cpu_fft_arm_20261031.csv
```

正常结束预期`cases: 12`，下载同目录`cpu_fft_arm_20261031.csv`及`cpu_fft_arm_20261031.json`回传。若任一文件已存在，改新编号`cpu_fft_arm_20261031_02.csv`，不覆盖原件。若目录/脚本缺失或报错，返回终端原文，先不重装r2。工具使用冻结同输入NumPy FFT，不加载Overlay；计时不包含ADC/DMA/绘图，不与capture总调用时间混作加速比。

ARM收件核验后，再统一安排r3的安全切换、单音/停止恢复/导出短复验及三次物理冷启动。r2的长测不冒充r3实测，不因导出等待设置变化默认重复30分钟。CMA归因、真实录像、最终报告与正式提交继续独立跟踪。

## 归档入口

- 新核验目录：`build/spectrum_board_validation_20261031_01/`。
- 机器receipt：`validation_receipt.json`、`rescue_verification.json`、`observer_audit.json`。
- 完整可信审计：`trusted_audit/audit.json`及14个run的独立审计。
- 数据表：`run_results.csv`、`long_run_memory.csv`、`observer_resources.csv`；失败详情：`failed_runs_diagnostic.json`。
- 新本地证据包：`release/spectrum_validation_20261031/A_spectrum_rescue_validation_20261031.zip`；原始旧包保持。
- 2026-10-30的8页DOCX/PDF继续作为当日候选稿，本页补充最新长测证据，未将旧报告冒称已回填的最终版。
