# r3实板短复验与原生导出核验

> 同日后续：r3三次实际冷启动已收件核验，见[冷启动结果](a_spectrum_r3_coldboot_validation_20261031.md)。当前以[基础复核清单](a_spectrum_basic_review_20261031.md)为入口，不再重复短测、冷启动或ARM。

日期：2026-10-31，Asia/Shanghai。状态：**BOARD_R3_SHORT_CAPTURE_RESTART_EXPORT_VERIFIED_COLD_BOOTS_PENDING**。当前部署已由原生会话确认是`spectrum_software_1_r3`。两次20秒Hann/在线1kHz单音、同服务停止恢复和原生会话导出均通过。**不重复r3短测、r2长测或ARM。下一步是三次实际冷启动，每次20秒。**

## 原件与可信审计

用户原件`spectrum_session_6dd45c6249f6_export01.zip`为926431字节，SHA256为`0465E96493BC1F9A9055620FABE767971B3D9D2B9090EEF36F34B2CE2255E5A1`。原件和两份外传PNG已复制到`build/spectrum_r3_validation_20261031_01/originals/`，哈希一致。

本次是板端原生整会话格式，可信审计器直接核验ZIP的CRC/边界、会话及run manifest、全部文件哈希、帧序号/状态、8份留样复数重建/谱指标及8张图，无需本地重建会话。两份外传PNG均与对应run的包内截图逐字节一致；部分图是同一帧重复保存，未作为不同采集帧计数。未执行收到的代码。

实例为`instrument_6dd45c6249f6`，r3 manifest为`7F1DA7D0BA2CE892CA3A318D0DE76360075FDA2545198EE374D614E0765662A5`，35份文件身份验证通过；bit/hwh仍与冻结v1.0相同。fs实测47998.57720194543 Hz。共4次运行、321帧、8份有限原始留样、8张图，4次功能运行和安全停止均通过，无失败记录，跨run序号0→321连续。

| run | 场景 | 帧数 | 时长秒 | 完成原因 | 序号 |
| --- | --- | ---: | ---: | --- | --- |
| spectrum_44b6d4d6f820 | observe/Hann | 100 | 20.012573521 | DURATION_COMPLETE | 0→100 |
| spectrum_90147db73014 | observe/Hann | 21 | 4.180814233 | STOP_REQUESTED | 100→121 |
| spectrum_003001ab96a1 | tone1k/Hann | 100 | 20.019106641 | DURATION_COMPLETE | 121→221 |
| spectrum_f06591b444a5 | tone1k/Hann | 100 | 20.016677435 | DURATION_COMPLETE | 221→321 |

前两次是早期观察运行，不冒称在线单音断言。最后两次均为20秒/5Hz/expected_tones=[1000]，200帧在线单音及状态检查通过，同服务/同Overlay初始与停止序号衔接。两次最长连续前台分别19.925228296秒和19.768533417秒，属于本轮短测。原生ZIP和截图证明导出产物有效，没有独立HTTP耗时记录，不声称测得导出等待时长。

通用完整矩阵审计仍输出`SESSION_DATA_VERIFIED_REQUIREMENTS_PENDING`：本包没有r3连续600秒、双音和静音，相关字段保持false；这不妨碍本轮预定短测清单通过，也不放宽完整矩阵的断言。r2已通过的1820秒/前台1819.799秒及12类ARM基准继续作为各自版本/平台证据，不冒称r3长测。CMA分配来源尚未查明，`board_accepted=false`保持。

## 冷启动工具已准备

新增独立`record_spectrum_boot_r3.py`，放在`release/spectrum_r3_boot_tools_20261031/`，供上传到Jupyter根目录。它严格固定可信r3 manifest，并验证35份负载、bit/hwh和Notebook源，只读文件和`/proc`，不导入PYNQ或加载Overlay。它与旧固定r2的记录器分开，不修改r3板端软件包、旧脚本或任何manifest。

7项HOST检查通过：正确r3及模拟boot身份、允许Notebook执行输出、Python3.6语法/无硬件导入、拒绝r2包、manifest改变、程序/bitstream改变、Notebook源/附加代码改变。测试没有板卡访问，不等于已经做过物理冷启动。脚本输出包含工具自身SHA256；输出文件使用新随机编号且不覆盖已有文件。

## 当前下一步

按[r3三次冷启动步骤](r3三次冷启动_20261031.md)：上传新脚本到Jupyter根目录，当前服务正常退出后安全关机、实际断电再上电；分别记录boot01、boot02、boot03，每轮r3/Hann/tone1k/20秒/5Hz并保存图、导出。回传3份boot JSON、3个原生会话ZIP及实际供电说明。三个boot_id必须不同；不能把当前会话或只重启软件算作三次断电上电。

工具、逐步命令和回传目录已备。当前没有三次冷启动回执，真实LIVE录像、CMA归因及最终DOCX/PDF/验收仍待后续。旧材料保持候选稿和历史快照，不将本页称为最终整机验收。

本轮审计目录：`build/spectrum_r3_validation_20261031_01/`。本地证据包：`release/spectrum_validation_20261031/A_spectrum_r3_validation_20261031.zip`；旧证据包及原软件ZIP不覆盖。
